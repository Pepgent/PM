# F26 S1

Reproduce from the soroi checkout:

```sh
bun run --cwd e2e f26 --config /tmp/soroi-observer-cli-49y_mho7/F26.json
```

The build fields identify the tested runtime. Fixture builds are not live acceptance evidence.
