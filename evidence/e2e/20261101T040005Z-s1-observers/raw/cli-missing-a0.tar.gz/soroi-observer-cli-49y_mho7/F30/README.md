# F30 S1

Reproduce from the soroi checkout:

```sh
bun run --cwd e2e f30 --config /tmp/soroi-observer-cli-49y_mho7/F30.json
```

The build fields identify the tested runtime. Fixture builds are not live acceptance evidence.
