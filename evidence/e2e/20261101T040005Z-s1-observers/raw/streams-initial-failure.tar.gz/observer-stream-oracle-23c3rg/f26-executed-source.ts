import { list, number, object, text } from "../standin/evidence.ts";
import { httpRef, recordedMain, span, type RecordedContext, type RecordedSpec, type RpcRecord } from "./recorded.ts";
import { committed, sse, storeSource } from "./observer-evidence.ts";
import { event } from "./wire.ts";
import { invocations } from "./scenario.ts";

export const F26_SEED = "const observer_input = 21";
export const F26_FIRST = "const observer_first = calc(observer_input)";
export const F26_SECOND = "const observer_second = calc(observer_first)";

function nativeTurn(frames: RpcRecord[], id: string): RpcRecord[] {
	const ack = frames.filter(frame => frame.type === "response" && frame.fields.command === "prompt" && frame.fields.id === id && frame.fields.success === true);
	const end = frames.filter(frame => frame.type === "prompt_result" && frame.fields.id === id && frame.fields.status === "completed");
	if (ack.length !== 1 || end.length !== 1 || ack[0]!.line >= end[0]!.line) throw new Error("Each reader/writer must observe the same complete native turn anchors");
	return frames.filter(frame => frame.line >= ack[0]!.line && frame.line <= end[0]!.line && !frame.type.startsWith("mux_"));
}

async function commitCursor(context: RecordedContext, phase: Awaited<ReturnType<typeof committed>>, input: unknown): Promise<number> {
	const ref = object(input), metadata = httpRef(ref), raw = await context.http(metadata, "/runs/steps", undefined, "POST", 201);
	const response = object(JSON.parse(raw)), request = object(await context.json(text(ref.request))), observation = object(await context.json(metadata.metadata));
	const run = object(request.run);
	context.check(`${phase.step}-store-request`, "The owning commit request and response are the actual native eval's session, code and run", storeSource("/runs/steps"), [phase.state.session, phase.record.code, phase.run, true], [request.session, request.code, response.run, run.kind === "existing" ? run.run === phase.run : run.kind === "open" && run.session === phase.state.session]);
	context.check(`${phase.step}-commit-window`, "The actual owning step exchange finishes within its causal prompt, not in an unrelated capture", context.source(phase.record.result, phase.root), true, number(observation.requestRpcLine) >= phase.request.sent.line && number(observation.responseRpcLine) < phase.request.completed.line);
	const seq = number(response.seq);
	if (!Number.isSafeInteger(seq) || seq < phase.step || seq !== phase.graph.at) throw new Error("Owning commit response must close this exact post-step graph prefix");
	return seq;
}

async function childReader(context: RecordedContext, input: unknown): Promise<void> {
	const row = object(input), parent = text(row.parent), child = text(row.child), reader = text(row.reader);
	if (reader === child) throw new Error("Reader and writer need separate raw evidence channels");
	const parentFrames = context.frames(parent, span(row.parentSpan)), spawn = invocations(parentFrames).find(call => call.id === row.spawnCall && call.name === "soroi_task");
	const spawned = spawn && parentFrames.find(frame => frame.type === "tool_execution_end" && frame.fields.toolCallId === spawn.id && frame.fields.isError === false);
	if (!spawn || !spawned || !list(object(object(spawned.fields.result).details).agents).map(object).some(agent => agent.id === child)) throw new Error("No actual supervisor result identifies the observed child");
	const writerFrames = context.frames(child, span(row.writerSpan)), readerFrames = context.frames(reader, span(row.readerSpan));
	const sends = context.rpc.filter(frame => frame.agent === child && frame.direction === "send" && frame.type === "prompt" && frame.line >= span(row.writerSpan).from && frame.line <= span(row.writerSpan).through);
	if (sends.length !== 1) throw new Error("The observed child turn needs one actual supervisor writer prompt");
	const sentPrompt = sends[0]!, state = context.state(child, span(row.writerSpan)), readerState = context.state(reader, span(row.readerSpan));
	context.check("reader-native-session", "The child writer and its reader query the same actual native session", context.source(readerState.frame, reader), state.session, readerState.session);
	const welcome = readerFrames.find(frame => frame.type === "mux_welcome"), started = readerFrames.find(frame => frame.type === "mux_generation_started");
	if (!welcome || (welcome.fields.generation === null && !started) || Math.max(welcome.line, started?.line ?? 0) >= sentPrompt.line) throw new Error("The child reader was not ready before its observed writer turn");
	const id = text(sentPrompt.fields.id), writer = nativeTurn(writerFrames, id), observed = nativeTurn(readerFrames, id);
	context.check("reader-all-stdout", "The already-attached child reader observes every raw native stdout frame byte-for-byte, including unknown types and other clients' responses", context.source(observed.at(-1)!, reader), writer.map(frame => frame.raw), observed.map(frame => frame.raw));
	const refusal = object(row.refusal), probe = text(refusal.channel), probeFrames = context.frames(probe, { from: 1, through: context.rpc.length });
	const sent = context.rpc.filter(frame => frame.agent === probe && frame.direction === "send" && frame.type === "prompt");
	if (sent.length !== 1) throw new Error("Forbidden prompt must actually be sent on its independent raw reader");
	const close = await context.readerClose(text(refusal.close), probe), closeLine = close.rpcLine, closeSource = { kind: "transcript" as const, file: `inputs/${text(refusal.close)}`, lines: [1, 1] as [number, number] };
	if (close.sendRpcLine !== sent[0]!.line || !probeFrames.some(frame => frame.type === "mux_welcome" && frame.line < sent[0]!.line)) throw new Error("Reader close is not bound to this actual raw prompt");
	context.check("reader-prompt-rejected", "Mux itself policy-closes the reader that actually sent prompt", closeSource, 1008, close.code);
	// These owner responses are recorded as raw native frames; the index names exact original lines only.
	const responseAt = (input: unknown, command: string) => {
		const frame = context.rpc[number(input) - 1];
		if (!frame || frame.agent !== child || frame.direction !== "receive" || frame.type !== "response" || frame.fields.command !== command || frame.fields.success !== true) throw new Error("Missing authoritative writer query around rejected reader prompt");
		return frame;
	};
	const beforeState = responseAt(refusal.stateBefore, "get_state"), afterState = responseAt(refusal.stateAfter, "get_state"), beforeMessages = responseAt(refusal.messagesBefore, "get_messages"), afterMessages = responseAt(refusal.messagesAfter, "get_messages");
	if (Math.max(beforeState.line, beforeMessages.line) >= sent[0]!.line || Math.min(afterState.line, afterMessages.line) <= closeLine) throw new Error("Actual writer queries do not bracket the raw reader rejection");
	context.check("reader-rejection-no-mutation", "The rejected reader prompt leaves the actual child's quiescent session and messages unchanged while writer queries continue", context.source(afterState, child), [state.session, state.session, false, false, object(beforeState.fields.data).messageCount, beforeMessages.fields.data], [object(beforeState.fields.data).sessionId, object(afterState.fields.data).sessionId, object(beforeState.fields.data).isStreaming, object(afterState.fields.data).isStreaming, object(afterState.fields.data).messageCount, afterMessages.fields.data]);
	const forbiddenId = text(sent[0]!.fields.id), body = text(sent[0]!.fields.message), prefix = text(probeFrames.find(frame => frame.type === "mux_welcome")!.fields.prefix);
	context.check("reader-prompt-not-delivered", "No forbidden reader prompt becomes native user input, starts an agent turn or gets a native prompt response", context.source(afterMessages, child), [], context.frames(child, { from: sent[0]!.line, through: afterMessages.line }).filter(frame => {
		if (frame.type === "agent_start" || frame.fields.id === `${prefix}${forbiddenId}`) return true;
		if (frame.type !== "message_end") return false;
		const message = object(frame.fields.message), content = message.content;
		return message.role === "user" && (typeof content === "string" ? content : Array.isArray(content) ? content.map(block => object(block).type === "text" ? text(object(block).text) : "").join("") : "") === body;
	}).map(frame => frame.fields));
}

export const f26: RecordedSpec = async (context, scenario) => {
	const seed = await committed(context, scenario.seed, F26_SEED), first = await committed(context, scenario.first, F26_FIRST), second = await committed(context, scenario.second, F26_SECOND);
	context.check("same-owning-run", "Both observed formal steps extend the same actual seeded root run", storeSource(`/runs/${seed.run}/graph`), [seed.run, seed.run, seed.state.session, seed.state.session], [first.run, second.run, first.state.session, second.state.session]);
	await context.graph(httpRef(first.phase.graph), seed.run, { kind: "between", receive: first.request.completed.line, send: second.request.sent.line });
	const firstEnd = await commitCursor(context, first, scenario.firstCommit), secondEnd = await commitCursor(context, second, scenario.secondCommit);
	const streams = [await context.stream(httpRef(scenario.initialStream), `/runs/${seed.run}/stream?after=${seed.graph.at}`, { send: first.request.sent.line, receive: first.request.completed.line }), await context.stream(httpRef(scenario.resumedStream), `/runs/${seed.run}/stream?after=${firstEnd}`, { send: second.request.sent.line, receive: second.request.completed.line })];
	const ends = [firstEnd, secondEnd], starts = [seed.graph.at, firstEnd], phases = [first, second];
	const combined = [];
	for (const [index, blocks] of streams.entries()) {
		const phase = phases[index]!, entries = blocks.flatMap(block => sse(`${block.raw}\n\n`).map(data => ({ event: event(data), rpcLine: block.rpcLine })));
		let previous = starts[index]!;
		for (const entry of entries) { if (entry.event.seq !== previous + 1) throw new Error("Run stream continuation has a gap, duplicate or out-of-order event"); previous = entry.event.seq; }
		context.check(`stream-${index}-cursor`, "The resumed segment ends at its owning step transaction response", storeSource(`/runs/${seed.run}/stream`), ends[index], previous);
		const steps = entries.filter(entry => entry.event.kind === "step_committed");
		context.check(`stream-${index}-one-group`, "Exactly one complete committed step group is pushed for this formal eval", storeSource(`/runs/${seed.run}/stream`), [[phase.step, phase.state.session, phase.record.code]], steps.map(entry => entry.event.kind === "step_committed" ? [entry.event.seq, entry.event.step.session, entry.event.step.code] : []));
		context.check(`stream-${index}-arrivals`, "This step's complete events arrive after its prompt and before the next action, not bulk-flushed later", storeSource(`/runs/${seed.run}/stream`), true, entries.length > 0 && entries.every(entry => entry.rpcLine >= phase.request.sent.line && (index === 1 || entry.rpcLine < second.request.sent.line)));
		context.check(`stream-${index}-members`, "All call events belong to this step and independent terminal events stay outside the step group", storeSource(`/runs/${seed.run}/stream`), true, entries.every(({ event }) => event.kind !== "run_ended" && event.kind !== "run_aborted" && (!("call" in event) || (event.call.kind !== "Root" && event.call.step === phase.step))));
		combined.push(...entries.map(entry => entry.event));
	}
	context.check("resumed-prefix", "Combined resumed segments equal the owning complete event prefix without replay or loss", storeSource(`/runs/${seed.run}/stream?after=0`), second.events.filter(event => event.seq > seed.graph.at), combined);
	for (const [phase, input, output, expected] of [[first, "observer_input", "observer_first", 42], [second, "observer_first", "observer_second", 84]] as const) {
		const calls = phase.graph.nodes.filter(node => node.kind === "Call" && node.step === phase.step);
		context.check(`${phase.step}-graph-group`, "Each pushed step is visible once in the matching graph with its actual calc input edge and output", storeSource(`/runs/${seed.run}/graph`), [["calc", "Program", [{ field: "", name: output, value: { kind: "scalar", scalar: { kind: "number", v: expected } } }]], [{ from: input, to: { step: phase.step, position: 0, input: 0 } }]], [calls.map(node => node.kind === "Call" ? [node.fn, node.body, node.outputs] : []), phase.graph.edges.filter(edge => edge.to.step === phase.step)]);
	}
	await childReader(context, scenario.childReader);
};
if (import.meta.main) await recordedMain("F26", f26);
