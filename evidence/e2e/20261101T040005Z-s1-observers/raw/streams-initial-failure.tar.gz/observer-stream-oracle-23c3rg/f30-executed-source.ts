import { text } from "../standin/evidence.ts";
import { httpRef, recordedMain, type RecordedSpec } from "./recorded.ts";
import { committed, sse, storeSource } from "./observer-evidence.ts";

export const F30_CODE = "const lifecycle_value = 21\nstop(lifecycle_value)";
export const f30: RecordedSpec = async (context, scenario) => {
	const phase = await committed(context, scenario.run, F30_CODE);
	const blocks = await context.stream(httpRef(scenario.lifecycle), "/stream/lifecycle", { send: phase.request.sent.line, receive: phase.request.completed.line });
	const events = blocks.flatMap(block => sse(`${block.raw}\n\n`).map(row => {
		const event = row.event;
		if (event !== "run_started" && event !== "run_ended" && event !== "run_aborted") throw new Error("Unknown lifecycle event");
		const derivedFrom = row.derivedFrom === null ? null : text(row.derivedFrom);
		const at = text(row.at), cursor = text(row.cursor), run = text(row.run), holder = text(row.holder);
		if (!cursor || !run || !holder || !Number.isFinite(Date.parse(at))) throw new Error("Incomplete lifecycle publication");
		return { event, derivedFrom, at, cursor, run, holder, rpcLine: block.rpcLine };
	}));
	const target = events.filter(event => event.run === phase.run);
	context.check("lifecycle-order", "The already-open global stream pushes exactly this run's start then end, with actual holder identity", storeSource("/stream/lifecycle"), ["run_started", "run_ended"], target.map(event => event.event));
	context.check("lifecycle-owning-root", "Both target lifecycle events name the owning root session and root run rather than caller-supplied labels", storeSource("/stream/lifecycle"), [[phase.state.session, null], [phase.state.session, null]], target.map(event => [event.holder, event.derivedFrom]));
	context.check("lifecycle-arrivals", "Target lifecycle events arrive on the established observation after its causal prompt; opaque cursors are retained and distinct", storeSource("/stream/lifecycle"), true, target.length === 2 && target.every(event => event.rpcLine >= phase.request.sent.line) && new Set(target.map(event => event.cursor)).size === 2);
	context.check("lifecycle-ended", "Owning graph and actual formal tool independently confirm Ended after the lifecycle publication", storeSource(`/runs/${phase.run}/graph`), ["Ended", [], true], [phase.graph.state, phase.graph.unconsumed, phase.record.report.kind === "formal" && phase.record.report.runEnded]);
};
if (import.meta.main) await recordedMain("F30", f30);
