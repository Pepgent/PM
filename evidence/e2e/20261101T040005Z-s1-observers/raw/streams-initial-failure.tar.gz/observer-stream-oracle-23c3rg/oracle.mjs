// NON-LIVE ORACLE INPUT. Exercises consumer logic only; never writes A0 or Verdict.
import { mkdir, cp } from 'node:fs/promises';
import { join } from 'node:path';
const root='/Users/mouriya/Ext/worktrees/test-208-s1-observers-ff0716f';
const home='/tmp/observer-stream-oracle-23c3rg';
const {RecordedContext}=await import(`${root}/e2e/s1/recorded.ts`);
const {Evidence}=await import(`${root}/e2e/standin/evidence.ts`);
const {f26,F26_SEED,F26_FIRST,F26_SECOND}=await import(`${root}/e2e/s1/f26.spec.ts`);
const {f30,F30_CODE}=await import(`${root}/e2e/s1/f30.spec.ts`);
const at='2026-11-01T12:00:00.000Z';
const eid='23c3a341-2046-4d54-93cf-9bcdb2e1c111';
const run='01K90000000000000000000001', other='01K90000000000000000000002';
const session='native-root-stream-oracle', child='native-child-writer', reader='child-reader-observer', probe='raw-refusal-reader';
const hash='a'.repeat(64); // Address-shaped field only: never behavior evidence.
const scalar=v=>({kind:'scalar',scalar:{kind:'number',v}});
const pretty=v=>JSON.stringify(v,null,2)+'\n';
const write=async(path,value)=>Bun.write(path,typeof value==='string'?value:pretty(value));
class Input {
  rows=[]; files=new Map(); entries=[];
  rpc(channel,direction,fields,raw=JSON.stringify(fields)){this.rows.push({evidenceId:eid,at,direction,channel,raw});return this.rows.length;}
  receive(channel,fields){return this.rpc(channel,'receive',fields);}
  send(channel,fields){return this.rpc(channel,'send',fields);}
  query(channel,command,data){this.send(channel,{type:command,id:`${command}-${this.rows.length}`});return this.receive(channel,{type:'response',command,success:true,data});}
  http(name,path,body,request,response,extra={}){const metadata=`store/${name}.json`;this.files.set(metadata,{evidenceId:eid,method:'GET',path,status:200,requestRpcLine:request,responseRpcLine:response,capture:{kind:'complete'},headers:[['content-type','application/json']],...extra});this.files.set(`store/${name}.body`,typeof body==='string'?body:JSON.stringify(body));return {metadata};}
  stream(name,path,events,request,headers,response,arrivals){const blocks=events.map((event,i)=>({raw:(i===0?'event: update\r\n':'')+'data: '+JSON.stringify(event),rpcLine:arrivals[i]}));const ref=this.http(name,path,blocks.map(b=>b.raw+'\r\n\r\n').join(''),request,response,{headers:[['content-type','text/event-stream; charset=utf-8']],capture:{kind:'stream',headersRpcLine:headers,blocks}});return ref;}
  phase(label,code,report,graph,events){const rootChannel='root-writer',start=this.rows.length+1,id=`prompt-${label}`,call=`eval-${label}`,prompt=`NON-LIVE ORACLE INPUT: execute exact ${label} code ${code}`;
    const sent=this.send(rootChannel,{type:'prompt',id,message:prompt});
    this.receive(rootChannel,{type:'response',command:'prompt',id,success:true});
    this.receive(rootChannel,{type:'agent_start'});
    const user={role:'user',content:[{type:'text',text:prompt}],timestamp:Date.parse(at)};
    this.receive(rootChannel,{type:'message_end',message:user});
    const args={mode:'formal',code};
    const assistant={role:'assistant',content:[{type:'toolCall',id:call,name:'soroi_eval',arguments:args}],api:'openai-responses',provider:'openai',model:'NON-LIVE',stopReason:'toolUse',timestamp:Date.parse(at)};
    this.receive(rootChannel,{type:'message_end',message:assistant});
    this.receive(rootChannel,{type:'tool_execution_start',toolCallId:call,toolName:'soroi_eval',args});
    const commitRequest=this.rows.length;
    this.receive(rootChannel,{type:'message_update',assistantMessageEvent:{type:'text_delta',delta:''}});
    const commitResponse=this.rows.length;
    const result=this.receive(rootChannel,{type:'tool_execution_end',toolCallId:call,toolName:'soroi_eval',isError:false,result:{content:[{type:'text',text:JSON.stringify(report)}],details:report}});
    this.receive(rootChannel,{type:'agent_end',messages:[]});
    const completed=this.receive(rootChannel,{type:'prompt_result',id,status:'completed'});
    this.query(rootChannel,'get_state',{sessionId:session,messageCount:this.entries.length+3,isStreaming:false});
    const append=(suffix,message)=>{const entry={type:'message',id:`${label}-${suffix}`,parentId:this.entries.at(-1)?.id??null,timestamp:at,message};this.entries.push(entry);};
    append('user',user);append('assistant',assistant);append('result',{role:'toolResult',toolCallId:call,toolName:'soroi_eval',content:[{type:'text',text:JSON.stringify(report)}],details:report,isError:false,timestamp:Date.parse(at)});
    this.query(rootChannel,'get_entries',{entries:structuredClone(this.entries),leafId:this.entries.at(-1).id});
    const after=this.rows.length;
    const graphRef=this.http(`${label}-graph`,`/runs/${run}/graph`,graph,after,after);
    const eventsRef=this.http(`${label}-events`,`/runs/${run}/stream?after=0`,events.map(e=>'data: '+JSON.stringify(e)+'\n\n').join(''),after,after,{headers:[['content-type','text/event-stream']]});
    return {index:{root:rootChannel,span:{from:start,through:after},graph:graphRef,events:eventsRef},sent,completed,result,commitRequest,commitResponse,after};
  }
  async save(dir,scenario){await mkdir(dir,{recursive:true});await mkdir(join(dir,'store'),{recursive:true});for(const [name,value]of this.files)await write(join(dir,name),value);await write(join(dir,'rpc.jsonl'),this.rows.map(r=>JSON.stringify(r)).join('\n')+'\n');await write(join(dir,'scenario.json'),{label:'NON-LIVE ORACLE INPUT',...scenario});await write(join(dir,'NOTICE.txt'),'NON-LIVE ORACLE INPUT\nNo product was run. This is not live evidence, A0, or a D8 Verdict.\n');}
}
const event=(kind,seq,extra={})=>({kind,seq,at,...extra});
const step=(seq,code)=>event('step_committed',seq,{step:{session,code}});
const callNode=(stepNum,name,value)=>({kind:'Call',capture:hash,step:stepNum,position:0,fn:'calc',version:hash,body:'Program',env:{kind:'central'},status:{kind:'Ended'},startedAt:at,endedAt:at,transcript:null,outputs:[{field:'',name,value:scalar(value)}]});
const graph=(state,seq,nodes,edges,unconsumed)=>({run,holder:session,derivedFrom:null,state,at:seq,nodes,edges,unconsumed});
const report=(started,ended,calls=[])=>({ok:true,mode:'formal',runId:run,runStarted:started,runEnded:ended,calls});
const calcReport=name=>[{call:'calc(observer_input)',outcome:'ran',env:'central',outputs:{'':name}}];
const version={version:hash,bundle:hash,entry:hash,sources:hash,commit:'NON-LIVE-ORACLE-ADDRESS',buildManifest:hash,lockfile:hash};
function commitBody(code,node,inputName,outputName,value){return {run:{kind:'existing',run},session,code,transfer:'01K90000000000000000000003',roots:[],calls:[{position:0,fn:'calc',inputNames:[inputName],outputNames:[{field:'',name:outputName}],startedAt:at,endedAt:at,outcome:{kind:'Done',origin:{kind:'Executed',site:{kind:'central'},capture:{identity:hash,fn:'calc',version:hash,body:'Program',env:{kind:'central'},inputs:[hash],outputs:[{field:'',value:scalar(value)}],transcript:null}}}}],stops:[],versions:[version]};}
function childObservation(input){
  const parent='native-supervisor',spawnCall='spawn-child-1',parentStart=input.rows.length+1;
  input.send(parent,{type:'prompt',id:'supervisor-prompt',message:'NON-LIVE ORACLE INPUT: spawn observed child'});
  input.receive(parent,{type:'response',command:'prompt',id:'supervisor-prompt',success:true});
  input.receive(parent,{type:'message_end',message:{role:'assistant',content:[{type:'toolCall',id:spawnCall,name:'soroi_task',arguments:{tasks:[{name:child,task:'NON-LIVE observed task'}]}}]}});
  input.receive(parent,{type:'tool_execution_start',toolCallId:spawnCall,toolName:'soroi_task',args:{tasks:[{name:child,task:'NON-LIVE observed task'}]}});
  input.receive(parent,{type:'tool_execution_end',toolCallId:spawnCall,toolName:'soroi_task',isError:false,result:{content:[{type:'text',text:child}],details:{agents:[{id:child}]}}});
  input.receive(parent,{type:'prompt_result',id:'supervisor-prompt',status:'completed'});
  const parentEnd=input.rows.length;
  const begin=input.rows.length+1;
  input.receive(child,{type:'mux_welcome',prefix:'writer-',generation:'generation-child'});
  input.receive(reader,{type:'mux_welcome',prefix:'reader-',generation:'generation-child'});
  input.receive(reader,{type:'mux_generation_started',generation:'generation-child'});
  const promptId='writer-child-prompt';
  input.send(child,{type:'prompt',id:promptId,message:'NON-LIVE ORACLE INPUT observed child turn'});
  const mirror=fields=>{const raw=JSON.stringify(fields);input.rpc(child,'receive',fields,raw);return input.rpc(reader,'receive',fields,raw);};
  mirror({type:'response',command:'prompt',id:promptId,success:true});
  mirror({type:'agent_start'});
  mirror({type:'message_end',message:{role:'user',content:'NON-LIVE ORACLE INPUT observed child turn'}});
  mirror({type:'native_future_extension',payload:{opaque:'unknown frame retained byte-for-byte',unicode:'观察'}});
  mirror({type:'response',command:'get_state',id:'other-client-query',success:true,data:{sessionId:'native-child-session',isStreaming:true,messageCount:1}});
  mirror({type:'message_end',message:{role:'assistant',content:[{type:'text',text:'observed complete child'}]}});
  mirror({type:'agent_end',messages:[]});
  mirror({type:'prompt_result',id:promptId,status:'completed'});
  const state={sessionId:'native-child-session',messageCount:2,isStreaming:false};
  input.query(child,'get_state',state);input.query(reader,'get_state',state);
  const turnEnd=input.rows.length;
  const stateBefore=input.query(child,'get_state',state);
  const messages={messages:[{role:'user',content:'NON-LIVE ORACLE INPUT observed child turn'},{role:'assistant',content:[{type:'text',text:'observed complete child'}]}]};
  const messagesBefore=input.query(child,'get_messages',messages);
  input.receive(probe,{type:'mux_welcome',prefix:'probe-',generation:'generation-child'});
  const sendRpcLine=input.send(probe,{type:'prompt',id:'forbidden-1',message:'NON-LIVE forbidden reader mutation'});
  const closeLine=sendRpcLine;
  const deliverySlot=input.receive(child,{type:'mux_observation_marker',label:'no native prompt delivered'});
  const stateAfter=input.query(child,'get_state',state),messagesAfter=input.query(child,'get_messages',messages);
  input.files.set('reader-close.json',{evidenceId:eid,channel:probe,sendRpcLine,rpcLine:closeLine,code:1008});
  return {index:{parent,parentSpan:{from:parentStart,through:parentEnd},spawnCall,child,writerSpan:{from:begin,through:turnEnd},reader,readerSpan:{from:begin,through:turnEnd},refusal:{channel:probe,close:'reader-close.json',stateBefore,messagesBefore,stateAfter,messagesAfter}},deliverySlot};
}
async function build26(){const input=new Input();const rootNode={kind:'Root',name:'observer_input',value:scalar(21)};
  const firstNode=callNode(3,'observer_first',42),secondNode=callNode(6,'observer_second',84);
  const e0=[event('run_started',1),step(2,F26_SEED)];
  const e1=[...e0,step(3,F26_FIRST),event('call_started',4,{call:firstNode}),event('call_ended',5,{call:firstNode})];
  const e2=[...e1,step(6,F26_SECOND),event('call_started',7,{call:secondNode}),event('call_ended',8,{call:secondNode})];
  const edge1={from:'observer_input',to:{step:3,position:0,input:0}},edge2={from:'observer_first',to:{step:6,position:0,input:0}};
  const seed=input.phase('seed',F26_SEED,report(true,false),graph('Open',2,[rootNode],[],['observer_input']),e0);
  const first=input.phase('first',F26_FIRST,report(false,false,calcReport('observer_first')),graph('Open',5,[rootNode,firstNode],[edge1],['observer_first']),e1);
  const second=input.phase('second',F26_SECOND,report(false,false,[{...calcReport('observer_second')[0],call:'calc(observer_first)'}]),graph('Open',8,[rootNode,firstNode,secondNode],[edge1,edge2],['observer_second']),e2);
  const commit=(label,phase,code,node,from,to,v,seq)=>{const ref=input.http(`${label}-commit`,'/runs/steps',{run,seq},phase.commitRequest,phase.commitResponse,{method:'POST',status:201});const request=`store/${label}-commit.request`;input.files.set(request,commitBody(code,node,from,to,v));return {...ref,request};};
  const firstCommit=commit('first',first,F26_FIRST,firstNode,'observer_input','observer_first',42,5),secondCommit=commit('second',second,F26_SECOND,secondNode,'observer_first','observer_second',84,8);
  const initialStream=input.stream('initial-stream',`/runs/${run}/stream?after=2`,e1.slice(2),seed.after,seed.after,first.after,[first.commitResponse,first.commitResponse,first.commitResponse]);
  const resumedStream=input.stream('resumed-stream',`/runs/${run}/stream?after=5`,e2.slice(5),first.after,first.after,second.after,[second.commitResponse,second.commitResponse,second.commitResponse]);
  const childObs=childObservation(input);
  await input.save(join(home,'f26-positive'),{flow:'F26',seed:seed.index,first:first.index,second:second.index,firstCommit,secondCommit,initialStream,resumedStream,childReader:childObs.index});
  return {first,second,deliverySlot:childObs.deliverySlot};
}
async function build30(){const input=new Input();
  const events=[event('run_started',1),step(2,F30_CODE),event('atom_stopped',3,{name:'lifecycle_value'}),event('run_ended',4)];
  const phase=input.phase('lifecycle',F30_CODE,report(true,true),graph('Ended',4,[{kind:'Root',name:'lifecycle_value',value:scalar(21)}],[],[]),events);
  const rows=[{run,holder:session,derivedFrom:null,event:'run_started',at,cursor:'z:opaque/start'}, {run:other,holder:'other-native-holder',derivedFrom:null,event:'run_started',at,cursor:'other/opaque'}, {run:other,holder:'other-native-holder',derivedFrom:null,event:'run_aborted',at,cursor:'other/aborted'}, {run,holder:session,derivedFrom:null,event:'run_ended',at,cursor:'A:opaque/end'}];
  const lifecycle=input.stream('lifecycle-stream','/stream/lifecycle',rows,0,0,phase.after,[phase.commitResponse,phase.commitResponse,phase.commitResponse,phase.result]);
  await input.save(join(home,'f30-positive'),{flow:'F30',run:phase.index,lifecycle});return {phase};
}
const json=path=>Bun.file(path).json();
async function mutateSse(dir,ref,fn){const meta=await json(join(dir,ref));fn(meta.capture.blocks);await write(join(dir,ref),meta);await write(join(dir,ref.replace(/\.json$/,'.body')),meta.capture.blocks.map(b=>b.raw+'\r\n\r\n').join(''));}
async function createFamily(){const marks26=await build26(),marks30=await build30();const mutations=[];
  const variant=async(name,base,artifact,change,expect,fn)=>{const dir=join(home,name);await cp(join(home,base),dir,{recursive:true});await fn(dir);const m={name,label:'NON-LIVE ORACLE INPUT',base,artifact,semanticChange:change,expected:expect};await write(join(dir,'mutation.json'),m);mutations.push(m);};
  await variant('f26-missingseq','f26-positive','store/initial-stream.{json,body}','Remove seq=4 block only (body and block metadata kept equal)','Error: gap, duplicate or out-of-order',d=>mutateSse(d,'store/initial-stream.json',b=>b.splice(1,1)));
  await variant('f26-replay','f26-positive','store/resumed-stream.{json,body}','Replay one first-group seq=5 block at resumed beginning','Error: gap, duplicate or out-of-order',async d=>{const first=await json(join(d,'store/initial-stream.json'));await mutateSse(d,'store/resumed-stream.json',b=>b.unshift({...first.capture.blocks.at(-1),rpcLine:b[0].rpcLine}));});
  await variant('f26-wrongcommitseq','f26-positive','store/first-commit.body','Change owning POST response seq 5→4 only','Error: owning commit response must close exact graph',async d=>{const p=join(d,'store/first-commit.body'),v=await json(p);v.seq=4;await write(p,v);});
  await variant('f26-latefirstgrouparrival','f26-positive','store/initial-stream.json','Last first-group block arrival becomes second prompt line; extend capture finish watermark to retain structural validity','stream-0-arrivals',async d=>{const p=join(d,'store/initial-stream.json'),v=await json(p);v.capture.blocks.at(-1).rpcLine=marks26.second.sent;v.responseRpcLine=marks26.second.sent;await write(p,v);});
  await variant('f26-omitunknownnativeframe','f26-positive','rpc.jsonl','Reader unknown native stdout replaced by transport-only heartbeat at same ledger coordinate','reader-all-stdout',async d=>{const p=join(d,'rpc.jsonl'),v=(await Bun.file(p).text()).trim().split('\n').map(JSON.parse);const row=v.find(r=>r.channel===reader&&JSON.parse(r.raw).type==='native_future_extension');row.raw=JSON.stringify({type:'mux_heartbeat'});await write(p,v.map(JSON.stringify).join('\n')+'\n');});
  await variant('f26-wrongclosecode','f26-positive','reader-close.json','Policy close code 1008→1000 only','reader-prompt-rejected',async d=>{const p=join(d,'reader-close.json'),v=await json(p);v.code=1000;await write(p,v);});
  await variant('f26-forbiddenpromptdelivered','f26-positive','rpc.jsonl','One observation slot becomes child native user message containing forbidden prompt','reader-prompt-not-delivered',async d=>{const p=join(d,'rpc.jsonl'),v=(await Bun.file(p).text()).trim().split('\n').map(JSON.parse);v[marks26.deliverySlot-1].raw=JSON.stringify({type:'message_end',message:{role:'user',content:'NON-LIVE forbidden reader mutation'}});await write(p,v.map(JSON.stringify).join('\n')+'\n');});
  await variant('f30-wrongholder','f30-positive','store/lifecycle-stream.{json,body}','Target end holder changed to unrelated holder','lifecycle-owning-root',d=>mutateSse(d,'store/lifecycle-stream.json',b=>{const v=JSON.parse(b.at(-1).raw.slice(6));v.holder='wrong-native-holder';b.at(-1).raw='data: '+JSON.stringify(v);}));
  await variant('f30-aborted','f30-positive','store/lifecycle-stream.{json,body}','Target end event becomes run_aborted','lifecycle-order',d=>mutateSse(d,'store/lifecycle-stream.json',b=>{const v=JSON.parse(b.at(-1).raw.slice(6));v.event='run_aborted';b.at(-1).raw='data: '+JSON.stringify(v);}));
  await variant('f30-missingend','f30-positive','store/lifecycle-stream.{json,body}','Remove target run_ended publication only','lifecycle-order; lifecycle-owning-root; lifecycle-arrivals',d=>mutateSse(d,'store/lifecycle-stream.json',b=>b.pop()));
  for(const flow of ['f26','f30'])await variant(`${flow}-lateheaders`,`${flow}-positive`,flow==='f26'?'store/initial-stream.json':'store/lifecycle-stream.json','Headers observed at causal prompt send rather than before it','Error: SSE headers were not observed before causal prompt',async d=>{const p=join(d,flow==='f26'?'store/initial-stream.json':'store/lifecycle-stream.json'),v=await json(p);v.capture.headersRpcLine=flow==='f26'?marks26.first.sent:marks30.phase.sent;await write(p,v);});
  await write(join(home,'manifest.json'),{label:'NON-LIVE ORACLE INPUT',sourceRoot:root,evidenceId:eid,marks26,marks30,positive:['f26-positive','f30-positive'],mutations});
  console.log(pretty({constructed:true,home,positives:['f26-positive','f30-positive'],variants:mutations.map(m=>m.name)}));
}
async function executeFamily(){const manifest=await json(join(home,'manifest.json'));const outcomes=[];
  for(const name of [...manifest.positive,...manifest.mutations.map(m=>m.name)]){const inputDir=join(home,name),outDir=join(home,`${name}-output`);const evidence=await Evidence.create(outDir);const config={evidenceDir:outDir,inputDir,a0Verdict:join(home,'NO-A0-INTENTIONALLY-NOT-CREATED'),build:{commits:{},release:'NON-LIVE ORACLE INPUT',images:{},omp:'not-executed',model:'not-executed'},reproduce:`bun ${home}/oracle.mjs execute`};const context=new RecordedContext(config,evidence);let error=null;try{await context.loadRpc();const scenario=await context.json('scenario.json');await (name.startsWith('f26')?f26:f30)(context,scenario);}catch(e){error=e instanceof Error?e.stack:String(e);}const result={label:'NON-LIVE ORACLE INPUT; NOT A VERDICT',name,error,failed:context.assertions.filter(a=>!a.pass).map(a=>a.id),assertions:context.assertions};await write(join(outDir,'consumer-result.json'),result);outcomes.push(result);console.log(pretty(result));}
  await write(join(home,'results.json'),{label:'NON-LIVE ORACLE INPUT; NOT A VERDICT',outcomes});
}
if(process.argv[2]==='construct')await createFamily();else if(process.argv[2]==='execute')await executeFamily();else throw Error('Use construct or execute');
