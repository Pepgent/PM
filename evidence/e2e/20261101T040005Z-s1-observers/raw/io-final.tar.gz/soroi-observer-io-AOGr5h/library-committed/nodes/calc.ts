export default program(async (input: number): Promise<number> => new Decimal(input).times(3).toNumber());
