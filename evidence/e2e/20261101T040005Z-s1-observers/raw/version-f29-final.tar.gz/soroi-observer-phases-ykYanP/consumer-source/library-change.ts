import { join } from "node:path";
import { Evidence, list, number, object, text } from "./evidence.ts";

type CommandResult = { code: number; stdout: string; stderr: string };
export type LibraryChange = {
	kind: "committed"; evidenceId: string; cwd: string; command: string[];
	startedRpcLine: number; finishedRpcLine: number; result: CommandResult;
	beforeHead: string; afterHead: string; beforeSource: string; afterSource: string;
	baseline: { version: { metadata: string }; usage: { metadata: string } };
};
async function run(command: string[], cwd: string, timeoutMs: number): Promise<CommandResult> {
	const child = Bun.spawn(command, { cwd, stdin: "ignore", stdout: "pipe", stderr: "pipe", timeout: timeoutMs, killSignal: "SIGKILL" });
	const [code, stdout, stderr] = await Promise.all([child.exited, new Response(child.stdout).text(), new Response(child.stderr).text()]);
	return { code, stdout, stderr };
}

/** The explicit command performs the complete edit+commit. Git, not the working tree, supplies committed source. */
export async function observeLibraryChange(evidence: Evidence, options: { storeUrl: string; version: string; cwd: string; command: string[]; timeoutMs: number }): Promise<LibraryChange> {
	const { storeUrl, version, cwd, command, timeoutMs } = options;
	if (!command.length) throw new Error("Library change needs an explicit complete edit-and-commit argv");
	const file = join(evidence.dir, "library-change.json");
	if (await Bun.file(file).exists()) throw new Error("This recording already contains its library mutation");
	// These inner observations end before any Git mutation starts. Equal RPC watermarks cannot reorder them.
	const baselineGet = async (path: string) => {
		const request = evidence.beginHttp("GET", path), response = await fetch(new URL(path, storeUrl), { signal: AbortSignal.timeout(timeoutMs) });
		const ref = await evidence.http(request, response.status, response.headers, await response.text());
		if (!response.ok) throw new Error(`Library baseline GET ${path}: HTTP ${response.status}`);
		return ref;
	};
	const baseline = { usage: await baselineGet("/functions/calc/usage"), version: await baselineGet(`/versions/${version}`) };
	const startedRpcLine = evidence.rpcWatermark;
	const git = async (args: string[]) => {
		const result = await run(["git", ...args], cwd, timeoutMs);
		if (result.code !== 0) throw new Error(evidence.redact(`Git observation failed: ${result.stderr}`));
		return result.stdout;
	};
	const beforeHead = (await git(["rev-parse", "HEAD"])).trim(), beforeSource = await git(["show", `${beforeHead}:nodes/calc.ts`]);
	const result = await run(command, cwd, timeoutMs);
	if (result.code !== 0) {
		await Bun.write(file, evidence.redact(JSON.stringify({ kind: "failed", evidenceId: evidence.evidenceId, cwd, command, startedRpcLine, finishedRpcLine: evidence.rpcWatermark, result }, null, 2)));
		throw new Error("The complete library edit-and-commit command failed");
	}
	const afterHead = (await git(["rev-parse", "HEAD"])).trim(), afterSource = await git(["show", `${afterHead}:nodes/calc.ts`]);
	const observation: LibraryChange = { kind: "committed", evidenceId: evidence.evidenceId, cwd, command, startedRpcLine, finishedRpcLine: evidence.rpcWatermark, result, beforeHead, afterHead, beforeSource, afterSource, baseline };
	await Bun.write(file, evidence.redact(JSON.stringify(observation, null, 2)));
	return observation;
}
export function libraryChange(input: unknown): LibraryChange {
	const row = object(input), result = object(row.result), baseline = object(row.baseline);
	if (row.kind !== "committed") throw new Error("No successfully committed library change was observed");
	return { kind: row.kind, evidenceId: text(row.evidenceId), cwd: text(row.cwd), command: list(row.command).map(text), startedRpcLine: number(row.startedRpcLine), finishedRpcLine: number(row.finishedRpcLine), result: { code: number(result.code), stdout: text(result.stdout), stderr: text(result.stderr) }, beforeHead: text(row.beforeHead), afterHead: text(row.afterHead), beforeSource: text(row.beforeSource), afterSource: text(row.afterSource), baseline: { version: { metadata: text(object(baseline.version).metadata) }, usage: { metadata: text(object(baseline.usage).metadata) } } };
}
