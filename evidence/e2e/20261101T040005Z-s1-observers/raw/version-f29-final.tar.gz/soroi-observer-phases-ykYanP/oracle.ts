import { mkdir, chmod } from "node:fs/promises";
import { join } from "node:path";
import { Evidence } from "/Users/mouriya/Ext/worktrees/test-208-s1-observers-ff0716f/e2e/standin/evidence.ts";
import { RecordedContext, type RecordedSpec } from "/Users/mouriya/Ext/worktrees/test-208-s1-observers-ff0716f/e2e/s1/recorded.ts";
import { f27, F27_SEED, F27_DRY } from "/Users/mouriya/Ext/worktrees/test-208-s1-observers-ff0716f/e2e/s1/f27.spec.ts";
import { f28 } from "/Users/mouriya/Ext/worktrees/test-208-s1-observers-ff0716f/e2e/s1/f28.spec.ts";
import { f29, F29_CHANGED } from "/Users/mouriya/Ext/worktrees/test-208-s1-observers-ff0716f/e2e/s1/f29.spec.ts";
import { CALC_CODE } from "/Users/mouriya/Ext/worktrees/test-208-s1-observers-ff0716f/e2e/s1/observer-evidence.ts";
import type { Graph, Event, EvalOutcome } from "/Users/mouriya/Ext/worktrees/test-208-s1-observers-ff0716f/e2e/s1/wire.ts";

const LABEL = "NON-LIVE ORACLE INPUT";
const timestamp = "2026-11-01T00:00:00.000Z";
type Flow = "F27" | "F28" | "F29";
type Variant = "positive" | "graph-write" | "missing-phase" | "old-root" | "wrong-output" | "wrong-usage" | "old-record-mutated" | "unchanged-commit" | "wrong-new-value" | "cross-namespace" | "stale-http" | "historical-seed" | "branch-args-repaired" | "late-baseline" | "uncommitted-source" | "mismatched-head" | "missing-composite-baseline" | "independent-top-level-baseline";
type Case = { name: string; flow: Flow; variant: Variant; expectedFailure: string | string[] | null; expectedError: string | null };
const cases: Case[] = [
  { name: "f29-positive", flow: "F29", variant: "positive", expectedFailure: null, expectedError: null },
  { name: "f29-wrong-usage", flow: "F29", variant: "wrong-usage", expectedFailure: "usage-original-run", expectedError: null },
  { name: "f29-old-record-mutated", flow: "F29", variant: "old-record-mutated", expectedFailure: "old-version-immutable", expectedError: null },
  { name: "f29-unchanged-commit", flow: "F29", variant: "unchanged-commit", expectedFailure: ["version-commit-source", "committed-code-change"], expectedError: null },
  { name: "f29-wrong-new-value", flow: "F29", variant: "wrong-new-value", expectedFailure: "run-f29-changed-2-calc", expectedError: null },
  { name: "f29-late-baseline", flow: "F29", variant: "late-baseline", expectedFailure: null, expectedError: "The old version baseline must precede the complete library edit/commit, which must finish before the changed prompt" },
  { name: "f29-uncommitted-source", flow: "F29", variant: "uncommitted-source", expectedFailure: "library-committed-source", expectedError: null },
  { name: "f29-mismatched-head", flow: "F29", variant: "mismatched-head", expectedFailure: "version-commit-source", expectedError: null },
  { name: "f29-missing-composite-baseline", flow: "F29", variant: "missing-composite-baseline", expectedFailure: null, expectedError: "Expected an object" },
  { name: "f29-independent-top-level-baseline", flow: "F29", variant: "independent-top-level-baseline", expectedFailure: null, expectedError: "F29 baselines must come from the composite library-change observation, not independent scenario indexes" },
];
type NativeRow = { evidenceId: string; at: string; direction: "send" | "receive"; channel: string; raw: string };
type Phase = { root: string; span: { from: number; through: number }; graph: { metadata: string }; events: { metadata: string }; commit?: { metadata: string; request: string } };
type NativePhase = { phase: Phase; sent: number; toolResult: number; completed: number; end: number; session: string };
type NativeEntry = { type: "message"; id: string; parentId: string | null; timestamp: string; message: unknown };
class FixedInput {
  readonly files = new Map<string, string>();
  readonly rows: NativeRow[] = [];
  readonly evidenceId = crypto.randomUUID();
  readonly journals = new Map<string, NativeEntry[]>();
  constructor(readonly caseInfo: Case) {}
  row(channel: string, direction: "send" | "receive", fields: Record<string, unknown>): number {
    this.rows.push({ evidenceId: this.evidenceId, at: timestamp, direction, channel, raw: JSON.stringify(fields) });
    return this.rows.length;
  }
  json(path: string, data: unknown): void { this.files.set(path, JSON.stringify(data, null, 2) + "\n"); }
  http(name: string, path: string, body: unknown, watermark: number, raw = false): { metadata: string } {
    const metadata = `store/${name}.json`;
    this.json(metadata, { evidenceId: this.evidenceId, method: "GET", path, status: 200, requestRpcLine: watermark, responseRpcLine: watermark, capture: { kind: "complete" }, headers: [["content-type", raw ? "text/event-stream" : "application/json"]] });
    this.files.set(`store/${name}.body`, raw ? String(body) : JSON.stringify(body, null, 2) + "\n");
    return { metadata };
  }
  commit(name: string, native: NativePhase, graph: Graph, code: string, historical = false): { metadata: string; request: string } {
    const metadata = `store/${name}-commit.json`, request = `store/${name}-commit.request`;
    this.json(metadata, { evidenceId: this.evidenceId, method: "POST", path: "/runs/steps", status: 201, requestRpcLine: historical ? 0 : native.toolResult - 1, responseRpcLine: historical ? 0 : native.toolResult - 1, capture: { kind: "complete" }, headers: [["content-type", "application/json"]] });
    this.json(`store/${name}-commit.body`, { run: graph.run, seq: graph.at });
    const roots = graph.nodes.filter(node => node.kind === "Root").map(node => ({ name: node.name, value: node.value }));
    const calls = graph.nodes.flatMap(node => node.kind === "Call" ? [{ position: node.position, fn: node.fn, inputNames: graph.edges.filter(edge => edge.to.position === node.position).map(edge => edge.from), outputNames: node.outputs.map(output => ({ field: output.field, name: output.name })), outcome: { kind: "Done", origin: { kind: "Executed", site: { kind: "central" }, capture: { identity: `NON-LIVE-${graph.run}-capture`, fn: node.fn, version: node.version, body: node.body, env: node.env, inputs: roots.map(root => root.value), outputs: node.outputs.map(output => ({ field: output.field, value: output.value })), transcript: null } } }, startedAt: node.startedAt, endedAt: node.endedAt }] : []);
    this.json(request, { session: native.session, code, run: { kind: "open", session: native.session }, roots, calls, stops: [], versions: [] });
    return { metadata, request };
  }
  phase(root: string, session: string, code: string, mode: "formal" | "dry_run", report: EvalOutcome, initialMessages = 0): NativePhase {
    const from = this.rows.length + 1, promptId = `${root}-${mode}-prompt`, callId = `${root}-${mode}-eval`;
    const prompt = `${LABEL}: execute exactly ${mode} soroi_eval with code:\n${code}`;
    this.row(root, "send", { type: "get_state", id: `${promptId}-initial-state` });
    this.row(root, "receive", { type: "response", command: "get_state", id: `${promptId}-initial-state`, success: true, data: { sessionId: session, isStreaming: false, messageCount: initialMessages } });
    const sent = this.row(root, "send", { type: "prompt", id: promptId, message: prompt });
    this.row(root, "receive", { type: "response", command: "prompt", id: promptId, success: true });
    const user = { role: "user", content: [{ type: "text", text: prompt }], timestamp: 1793491200000 };
    const assistant = { role: "assistant", content: [{ type: "toolCall", id: callId, name: "soroi_eval", arguments: { mode, code } }], api: "openai-responses", provider: "NON-LIVE", model: "NON-LIVE", stopReason: "toolUse", timestamp: 1793491200001, usage: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, totalTokens: 0, cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 } } };
    this.row(root, "receive", { type: "message_end", message: user });
    this.row(root, "receive", { type: "message_end", message: assistant });
    this.row(root, "receive", { type: "tool_execution_start", toolCallId: callId, toolName: "soroi_eval", args: { mode, code } });
    const { kind, ...details } = report;
    const published = { ...details, mode: kind };
    const content = [{ type: "text", text: JSON.stringify(published) }];
    const toolResult = this.row(root, "receive", { type: "tool_execution_end", toolCallId: callId, toolName: "soroi_eval", result: { content, details: published }, isError: false });
    const toolMessage = { role: "toolResult", toolCallId: callId, toolName: "soroi_eval", content, details: published, isError: false, timestamp: 1793491200002 };
    this.row(root, "receive", { type: "message_end", message: toolMessage });
    const completed = this.row(root, "receive", { type: "prompt_result", id: promptId, status: "completed" });
    this.row(root, "send", { type: "get_state", id: `${promptId}-final-state` });
    this.row(root, "receive", { type: "response", command: "get_state", id: `${promptId}-final-state`, success: true, data: { sessionId: session, isStreaming: false, messageCount: initialMessages + 3 } });
    if (this.caseInfo.variant === "branch-args-repaired") {
      // Native execution-start carries the repaired code, while the later authoritative
      // active branch retains the original wrong assistant arguments for that same ID.
      assistant.content[0]!.arguments = { mode, code: "const repaired_wrong_input = 999" };
      this.rows[from + 4]!.raw = JSON.stringify({ type: "message_end", message: { ...assistant, content: [] } });
    }
    const prior = this.journals.get(root) ?? [];
    const additions: NativeEntry[] = [user, assistant, toolMessage].map((message, index) => ({ type: "message", id: `${promptId}-entry-${index}`, parentId: index === 0 ? prior.at(-1)?.id ?? null : `${promptId}-entry-${index - 1}`, timestamp, message }));
    const entries = [...prior, ...additions];
    this.journals.set(root, entries);
    this.row(root, "send", { type: "get_entries", id: `${promptId}-entries` });
    this.row(root, "receive", { type: "response", command: "get_entries", id: `${promptId}-entries`, success: true, data: { entries, leafId: entries.at(-1)!.id } });
    const end = this.rows.length;
    return { phase: { root, span: { from, through: end }, graph: { metadata: "" }, events: { metadata: "" } }, sent, toolResult, completed, end, session };
  }
  formal(root: string, session: string, run: string, code: string, inputName: string, outputName: string, output: number, version: string, oldRoot = false): { native: NativePhase; graph: Graph; events: Event[] } {
    const report: EvalOutcome = { kind: "formal", runId: run, runStarted: true, runEnded: false, calls: [{ call: code.split("\n").at(-1)!, outcome: "ran", env: "central", outputs: { [outputName]: String(output) } }] };
    const native = this.phase(root, session, code, "formal", report, oldRoot ? 3 : 0);
    const call = { kind: "Call" as const, step: 2, position: 0, fn: "calc", version, body: "Program" as const, env: { kind: "central" as const }, status: { kind: "Ended" as const }, startedAt: timestamp, endedAt: timestamp, transcript: null, outputs: [{ field: "", name: outputName, value: numberValue(output) }] };
    const graph: Graph = { run, holder: session, derivedFrom: null, state: "Open", at: 4, nodes: [{ kind: "Root", name: inputName, value: numberValue(21) }, call], edges: [{ from: inputName, to: { step: 2, position: 0, input: 0 } }], unconsumed: [outputName] };
    const events: Event[] = [{ kind: "run_started", seq: 1, at: timestamp }, { kind: "step_committed", seq: 2, at: timestamp, step: { session, code } }, { kind: "call_started", seq: 3, at: timestamp, call }, { kind: "call_ended", seq: 4, at: timestamp, call }];
    native.phase.graph = this.http(`${run}-graph`, `/runs/${run}/graph`, graph, native.end);
    native.phase.events = this.http(`${run}-events`, `/runs/${run}/stream?after=0`, sse(events), native.end, true);
    native.phase.commit = this.commit(run, native, graph, code);
    return { native, graph, events };
  }
}
function numberValue(v: number): { kind: "scalar"; scalar: { kind: "number"; v: number } } { return { kind: "scalar", scalar: { kind: "number", v } }; }
function sse(events: Event[]): string { return events.map(event => `data: ${JSON.stringify(event)}\n\n`).join(""); }
function versionRecord(version: string, commit: string) { return { version, bundle: `bundle-${version}`, entry: "calc.ts", sources: `sources-${version}`, commit, buildManifest: `manifest-${version}`, lockfile: `lockfile-${version}` }; }
function construct(info: Case): FixedInput {
  const input = new FixedInput(info);
  let scenario: Record<string, unknown>;
  if (info.flow === "F27") {
    const session = "session-f27", run = "run-f27";
    const seed = input.phase("root-f27", session, F27_SEED, "formal", { kind: "formal", runId: run, runStarted: true, runEnded: false, calls: [] });
    const graph: Graph = { run, holder: session, derivedFrom: null, state: "Open", at: 2, nodes: [{ kind: "Root", name: "pending", value: numberValue(21) }], edges: [], unconsumed: ["pending"] };
    const events: Event[] = [{ kind: "run_started", seq: 1, at: timestamp }, { kind: "step_committed", seq: 2, at: timestamp, step: { session, code: F27_SEED } }];
    seed.phase.graph = input.http("seed-graph", `/runs/${run}/graph`, graph, seed.end);
    seed.phase.events = input.http("seed-events", `/runs/${run}/stream?after=0`, sse(events), seed.end, true);
    seed.phase.commit = input.commit("seed", seed, graph, F27_SEED, info.variant === "historical-seed");
    const before = input.http("dry-before", `/runs/${run}/graph`, graph, seed.end);
    const dry = input.phase("root-f27", session, F27_DRY, "dry_run", { kind: "dry_run", calls: [{ call: F27_DRY, outcome: "ran", env: "central", outputs: { dry_output: "42" } }] }, 3);
    const afterGraph = structuredClone(graph);
    if (info.variant === "graph-write") afterGraph.nodes = [{ kind: "Root", name: "pending", value: numberValue(22) }];
    const after = input.http("dry-after", `/runs/${run}/graph`, afterGraph, info.variant === "stale-http" ? dry.completed - 1 : dry.end);
    const dryEvents = input.http("dry-events", `/runs/${run}/stream?after=0`, sse(events), dry.end, true);
    scenario = { flow: info.flow, seed: seed.phase, dry: { root: dry.phase.root, span: dry.phase.span, before, after, events: dryEvents } };
    if (info.variant === "missing-phase") delete scenario.dry;
  } else if (info.flow === "F28") {
    const calc = input.formal("root-f28", "session-f28", "run-f28", CALC_CODE, "calc_input", "calc_output", info.variant === "wrong-output" ? 43 : 42, "version-double", info.variant === "old-root");
    scenario = { flow: info.flow, calc: calc.native.phase };
    if (info.variant === "cross-namespace") {
      const metadata = JSON.parse(input.files.get(calc.native.phase.graph.metadata)!);
      metadata.evidenceId = crypto.randomUUID();
      input.json(calc.native.phase.graph.metadata, metadata);
    }
  } else {
    const original = input.formal("root-f29-original", "session-f29-original", "run-f29-original", CALC_CODE, "calc_input", "calc_output", 42, "version-double");
    const usage = input.http("usage", "/functions/calc/usage", [{ version: "version-double", runs: [{ run: original.graph.run, state: info.variant === "wrong-usage" ? "Ended" : original.graph.state, calls: info.variant === "wrong-usage" ? 2 : 1 }] }], original.native.end);
    const beforeRecord = versionRecord("version-double", "commit-double");
    const oldBefore = input.http("old-before", "/versions/version-double", beforeRecord, original.native.end + (info.variant === "late-baseline" ? 1 : 0));
    const changed = input.formal("root-f29-changed", "session-f29-changed", "run-f29-changed", F29_CHANGED, "changed_input", "changed_output", info.variant === "wrong-new-value" ? 42 : 63, "version-triple");
    const oldAfter = input.http("old-after", "/versions/version-double", { ...beforeRecord, ...(info.variant === "old-record-mutated" ? { sources: "mutated-original-sources" } : {}) }, changed.native.end);
    const newVersion = input.http("new-version", "/versions/version-triple", versionRecord("version-triple", info.variant === "unchanged-commit" ? "commit-double" : info.variant === "mismatched-head" ? "commit-unrelated" : "commit-triple"), changed.native.end);
    const beforeSource = `// ${LABEL}\nexport const calc = (value) => value.times(2);\n`;
    input.json("library-change.json", { kind: "committed", evidenceId: input.evidenceId, cwd: "/NON-LIVE-ORACLE/library", command: ["NON-LIVE-ORACLE-edit-and-commit"], startedRpcLine: original.native.end, finishedRpcLine: original.native.end, result: { code: 0, stdout: `${LABEL}: synthetic edit/commit observation`, stderr: "" }, beforeHead: "commit-double", afterHead: "commit-triple", beforeSource, afterSource: info.variant === "uncommitted-source" ? beforeSource : beforeSource.replace(".times(2)", ".times(3)"), ...(info.variant === "missing-composite-baseline" || info.variant === "independent-top-level-baseline" ? {} : { baseline: { usage, version: oldBefore } }) });
    scenario = { flow: info.flow, original: original.native.phase, changed: changed.native.phase, oldAfter, newVersion, change: "library-change.json", ...(info.variant === "independent-top-level-baseline" ? { usage, oldBefore } : {}) };
  }
  input.files.set("rpc.jsonl", input.rows.map(row => JSON.stringify(row)).join("\n") + "\n");
  input.json("scenario.json", scenario);
  input.json("oracle-input.json", { label: LABEL, ...info, evidenceId: input.evidenceId, liveAcceptance: false, provenance: "Constructed fixed data, not captured from an installed product", watermarks: "same-ledger one-based original send/receive lines", observation: "full native prompt ACK user eval tool result completed prompt and active-branch get_entries plus native state; owner HTTP metadata/body" });
  return input;
}
async function prepare(root: string): Promise<void> {
  await mkdir(join(root, "inputs"));
  for (const info of cases) {
    const input = construct(info), dir = join(root, "inputs", info.name);
    await mkdir(dir); await mkdir(join(dir, "store"));
    for (const [path, raw] of input.files) { const file = join(dir, path); await Bun.write(file, raw); await chmod(file, 0o444); }
    await chmod(join(dir, "store"), 0o555); await chmod(dir, 0o555);
  }
  await chmod(join(root, "inputs"), 0o555);
  await Bun.write(join(root, "family.json"), JSON.stringify({ label: LABEL, cases }, null, 2) + "\n");
  console.log(JSON.stringify({ label: LABEL, operation: "prepared", root, inputsReadOnly: true, cases: cases.map(info => info.name) }));
}
async function execute(root: string): Promise<void> {
  const out = join(root, "outputs"); await mkdir(out);
  const specs: Record<Flow, RecordedSpec> = { F27: f27, F28: f28, F29: f29 };
  for (const info of cases) {
    const dir = join(out, info.name), inputDir = join(root, "inputs", info.name);
    const evidence = await Evidence.create(dir);
    const context = new RecordedContext({ evidenceDir: dir, inputDir, a0Verdict: join(root, "NO-A0-NON-LIVE"), build: { commits: { oracle: "NON-LIVE" }, release: "NON-LIVE", images: {}, omp: "NON-LIVE", model: "NON-LIVE" }, reproduce: `bun ${join(root, "oracle.ts")} execute ${root}` }, evidence);
    let error: { name: string; message: string; stack?: string } | null = null;
    try { await context.loadRpc(); const scenario = await context.json("scenario.json"); await specs[info.flow](context, scenario as Record<string, unknown>); }
    catch (caught) { error = caught instanceof Error ? { name: caught.name, message: caught.message, stack: caught.stack } : { name: "Unknown", message: String(caught) }; }
    const failed = context.assertions.filter(assertion => !assertion.pass).map(assertion => assertion.id);
    const expectedFailures = info.expectedFailure === null ? [] : typeof info.expectedFailure === "string" ? [info.expectedFailure] : info.expectedFailure;
    const meetsExpectation = info.expectedError !== null ? error?.message === info.expectedError && failed.length === 0 : error === null && JSON.stringify(failed) === JSON.stringify(expectedFailures) && context.assertions.length > 0;
    const result = { label: LABEL, case: info.name, flow: info.flow, liveAcceptance: false, expected: { failedId: info.expectedFailure, error: info.expectedError }, actual: { failed, error, assertions: context.assertions }, meetsExpectation, inputDir, outputDir: dir, evidenceOutputId: evidence.evidenceId };
    await Bun.write(join(dir, "oracle-result.json"), JSON.stringify(result, null, 2) + "\n");
    console.log(`CASE ${info.name} ${meetsExpectation ? "EXPECTED" : "UNEXPECTED"}`);
    for (const assertion of context.assertions) console.log(JSON.stringify({ case: info.name, ...assertion }));
    console.log(JSON.stringify({ case: info.name, failed, error, meetsExpectation }));
    if (!meetsExpectation) process.exitCode = 1;
  }
}
const [operation, root] = process.argv.slice(2);
if (!root?.startsWith("/tmp/soroi-observer-phases-")) throw new Error("Retained root must be in assigned /tmp prefix");
if (operation === "prepare") await prepare(root);
else if (operation === "execute") await execute(root);
else throw new Error("Use prepare or execute");
