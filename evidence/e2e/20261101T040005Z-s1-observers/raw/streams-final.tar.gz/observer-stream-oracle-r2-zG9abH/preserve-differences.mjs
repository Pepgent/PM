// Retain actual content differences, not hashes.
import { join } from 'node:path';
const root='/tmp/observer-stream-oracle-r2-zG9abH';
const manifest=await Bun.file(join(root,'manifest.json')).json();
const records=[];
for(const mutation of manifest.mutations){
 const proc=Bun.spawn(['diff','-ru','--exclude=mutation.json',join(root,mutation.base),join(root,mutation.name)],{stdout:'pipe',stderr:'pipe'});
 const [stdout,stderr,code]=await Promise.all([new Response(proc.stdout).text(),new Response(proc.stderr).text(),proc.exited]);
 await Bun.write(join(root,`${mutation.name}.diff`),stdout);
 if(code!==0&&code!==1)throw Error(`diff failed: ${stderr}`);
 records.push({name:mutation.name,exitCode:code,differences:stdout,stderr});
}
await Bun.write(join(root,'actual-mutation-differences.json'),JSON.stringify(records,null,2)+'\n');
console.log(JSON.stringify(records.map(r=>({name:r.name,exitCode:r.exitCode,stderr:r.stderr})),null,2));
