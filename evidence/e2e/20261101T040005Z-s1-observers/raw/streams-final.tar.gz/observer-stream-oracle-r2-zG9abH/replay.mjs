// NON-LIVE ORACLE INPUT. Replays complete recorded inputs; does not write Verdict/A0.
import { join } from 'node:path';
import { RecordedContext } from '/Users/mouriya/Ext/worktrees/test-208-s1-observers-ff0716f/e2e/s1/recorded.ts';
import { Evidence } from '/Users/mouriya/Ext/worktrees/test-208-s1-observers-ff0716f/e2e/standin/evidence.ts';
import { f26 } from '/Users/mouriya/Ext/worktrees/test-208-s1-observers-ff0716f/e2e/s1/f26.spec.ts';
import { f30 } from '/Users/mouriya/Ext/worktrees/test-208-s1-observers-ff0716f/e2e/s1/f30.spec.ts';
const inputRoot='/tmp/observer-stream-oracle-r2-zG9abH';
const outputRoot=process.argv[2];
if(!outputRoot?.startsWith('/tmp/'))throw Error('Supply an existing fresh /tmp output root');
const manifest=await Bun.file(join(inputRoot,'manifest.json')).json();
const results=[];
for(const name of [...manifest.positive,...manifest.mutations.map(m=>m.name)]){
 const inputDir=join(inputRoot,name),evidenceDir=join(outputRoot,name);
 const evidence=await Evidence.create(evidenceDir);
 const context=new RecordedContext({evidenceDir,inputDir,a0Verdict:'/tmp/INTENTIONALLY-NO-A0',build:{commits:{},release:'NON-LIVE ORACLE INPUT',images:{},omp:'not-executed',model:'not-executed'},reproduce:`bun ${inputRoot}/replay.mjs <fresh-/tmp-output-root>`},evidence);
 let error=null;
 try {await context.loadRpc();await (name.startsWith('f26')?f26:f30)(context,await context.json('scenario.json'));}
 catch(e){error=e instanceof Error?e.stack:String(e);}
 const result={label:'NON-LIVE ORACLE INPUT; NOT A VERDICT',name,error,failed:context.assertions.filter(a=>!a.pass).map(a=>a.id),assertions:context.assertions};
 await Bun.write(join(evidenceDir,'consumer-result.json'),JSON.stringify(result,null,2)+'\n');
 results.push(result);console.log(JSON.stringify(result));
}
await Bun.write(join(outputRoot,'results.json'),JSON.stringify({label:'NON-LIVE ORACLE INPUT; NOT A VERDICT',outcomes:results},null,2)+'\n');
