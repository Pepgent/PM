import { object } from "../standin/evidence.ts";
import { httpRef, recordedMain, type RecordedSpec } from "./recorded.ts";
import { committed, evaluation, ensureSuccessfulCalc, storeSource } from "./observer-evidence.ts";

export const F27_SEED = "const pending = 21";
export const F27_DRY = "const dry_output = calc(pending)";
export const f27: RecordedSpec = async (context, scenario) => {
	const seed = await committed(context, scenario.seed, F27_SEED), dry = evaluation(context, scenario.dry, "dry_run", F27_DRY);
	ensureSuccessfulCalc(dry);
	context.check("seed-current-open", "The scripted seed actually opens this run rather than reusing a historical seed commitment", context.source(seed.record.result, seed.root), true, seed.record.report.kind === "formal" && seed.record.report.runStarted);
	context.check("dry-same-session", "Dry evaluation observes the same owning root session as the unfinished run", context.source(dry.state.frame, dry.root), seed.state.session, dry.state.session);
	const phase = object(scenario.dry), before = await context.graph(httpRef(phase.before), seed.run, { kind: "between", receive: seed.request.completed.line, send: dry.request.sent.line });
	const after = await context.graph(httpRef(phase.after), seed.run, { kind: "after", receive: dry.request.completed.line });
	context.check("unfinished-run", "The owning graph is Open with the actual seeded atom left unconsumed", storeSource(`/runs/${seed.run}/graph`), ["Open", ["pending"], [{ kind: "Root", name: "pending", value: { kind: "scalar", scalar: { kind: "number", v: 21 } } }]], [before.state, before.unconsumed, before.nodes]);
	context.check("dry-no-write", "The actual dry run leaves the complete owning graph, state and sequence unchanged", storeSource(`/runs/${seed.run}/graph`), before, after);
	context.check("seed-observation", "The pre-dry graph is the completed seed, not another run state", storeSource(`/runs/${seed.run}/graph`), seed.graph, before);
	const events = await context.events(httpRef(phase.events), seed.run, after.at, { kind: "after", receive: dry.request.completed.line });
	context.check("dry-no-commit", "The post-dry owning event prefix contains only the original formal seed step", storeSource(`/runs/${seed.run}/stream?after=0`), [F27_SEED], events.filter(event => event.kind === "step_committed").map(event => event.kind === "step_committed" ? event.step.code : ""));
};
if (import.meta.main) await recordedMain("F27", f27);
