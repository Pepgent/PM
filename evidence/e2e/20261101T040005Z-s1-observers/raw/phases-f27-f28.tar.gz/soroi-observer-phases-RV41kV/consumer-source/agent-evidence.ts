import { list, object, text } from "../standin/evidence.ts";
import type { Frame } from "../standin/lab-standin.ts";
import { invocations } from "./scenario.ts";
import { evalOutcome, type EvalOutcome } from "./wire.ts";
import type { HttpRef, RecordedContext } from "./recorded.ts";

export type EvalRecord = { id: string; code: string; mode: "formal" | "dry_run"; invocationLine: number; result: Frame; report: EvalOutcome; isError: boolean };
export function evalRecords(frames: Frame[]): EvalRecord[] {
	return invocations(frames).filter(call => call.name === "soroi_eval").map(call => {
		const result = frames.find(frame => frame.type === "tool_execution_end" && frame.fields.toolCallId === call.id);
		if (!result) throw new Error("Eval has no completed native tool result");
		const mode = call.args.mode;
		if (mode !== "formal" && mode !== "dry_run") throw new Error("Unexpected eval mode in recorded scenario");
		const tool = object(result.fields.result);
		// Parse the published report body independently of native isError: a failed capture still reports calls[].failed.
		const report = evalOutcome(tool.details, false, "");
		if (typeof result.fields.isError !== "boolean") throw new Error("Eval completion lacks its native error status");
		return { id: call.id, code: text(call.args.code), mode, invocationLine: call.line, result, report, isError: result.fields.isError };
	});
}
export function acceptedReturns(frames: Frame[]): { id: string; arguments: Record<string, unknown>; request: Frame; result: Frame }[] {
	return frames.filter(frame => frame.type === "host_tool_call" && frame.fields.toolName === "soroi_return").flatMap(request => {
		const id = text(request.fields.toolCallId);
		const result = frames.find(frame => frame.type === "tool_execution_end" && frame.fields.toolCallId === id && frame.fields.toolName === "soroi_return" && frame.fields.isError === false && frame.line > request.line);
		return result ? [{ id, arguments: object(request.fields.arguments), request, result }] : [];
	});
}
export function nativeAssistantBlocks(entries: Record<string, unknown>[]): Record<string, unknown>[] {
	return entries.flatMap(entry => {
		if (entry.type !== "message") return [];
		const message = object(entry.message);
		return message.role === "assistant" ? list(message.content).map(object) : [];
	});
}
export async function checkGeneration(context: RecordedContext, id: string, agent: string, ref: HttpRef, state: Frame): Promise<void> {
	const raw = await context.http(ref, "/agents/events");
	const events = raw.split(/\r?\n\r?\n/).flatMap(block => {
		const data = block.split(/\r?\n/).filter(line => line.startsWith("data:")).map(line => line.slice(5).replace(/^ /, "")).join("\n");
		return data ? [object(JSON.parse(data))] : [];
	});
	const marker = context.frames(agent, { from: 1, through: state.line }).findLast(frame => frame.type === "mux_welcome" || frame.type === "mux_generation_started" || frame.type === "mux_generation_exited");
	if (!marker || marker.type === "mux_generation_exited" || marker.fields.generation === null) throw new Error("The native state response has no live reader generation");
	const generation = text(marker.fields.generation);
	const starts = events.filter(event => event.kind === "generation_up" && event.agentId === agent && event.generation === generation);
	for (const event of starts) {
		const where = object(event.where);
		if (where.kind === "local") text(where.host);
		else if (where.kind === "remote") text(where.runId);
		else throw new Error("Unknown presence generation location");
	}
	context.check(id, "Mux presence records the local generation that produced this child's native state", { kind: "mux", path: "/agents/events" }, [1, "local"], [starts.length, starts[0] ? object(starts[0].where).kind : null]);
}
export function exactEval(context: RecordedContext, id: string, agent: string, frames: Frame[], code: string): EvalRecord {
	if (invocations(frames).length !== 1) throw new Error(`${id} deviated from the single scripted tool invocation`);
	const records = evalRecords(frames);
	if (records.length !== 1) throw new Error(`${id} needs exactly one original eval invocation`);
	const record = records[0]!;
	context.check(`${id}-script`, "The actual original formal tool code matches the owner-published workload invocation", context.source(record.result, agent), ["formal", code], [record.mode, record.code]);
	return record;
}
