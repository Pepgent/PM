import { object } from "../standin/evidence.ts";
import { recordedMain, type RecordedSpec } from "./recorded.ts";
import { CALC_CODE, checkCalc, committed, ensureSuccessfulCalc } from "./observer-evidence.ts";

export const f28: RecordedSpec = async (context, scenario) => {
	const phase = await committed(context, scenario.calc, CALC_CODE);
	ensureSuccessfulCalc(phase);
	const initial = phase.frames.filter(frame => frame.type === "response" && frame.fields.command === "get_state" && frame.fields.success === true && frame.line < phase.request.sent.line);
	if (initial.length !== 1) throw new Error("F28 needs one actual native initial state before the fresh root's first prompt");
	const state = object(initial[0]!.fields.data);
	context.check("fresh-root", "Named calc resolves in a genuinely fresh native root session", context.source(initial[0]!, phase.root), [phase.state.session, false, 0, true], [state.sessionId, state.isStreaming, state.messageCount, phase.record.report.kind === "formal" && phase.record.report.runStarted]);
	checkCalc(context, phase.graph, phase.step, "calc_input", "calc_output", 42);
	context.check("one-named-call", "The fresh root committed the intended calc exactly once, rather than an unrelated successful call", context.source(phase.record.result, phase.root), 1, phase.graph.nodes.filter(node => node.kind === "Call").length);
};
if (import.meta.main) await recordedMain("F28", f28);
