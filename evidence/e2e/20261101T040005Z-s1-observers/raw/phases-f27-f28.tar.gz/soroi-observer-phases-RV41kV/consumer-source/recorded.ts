import { isDeepStrictEqual } from "node:util";
import { isAbsolute, join, normalize } from "node:path";
import { Evidence, list, object, text, number, type Assertion, type Build, type Source, type Verdict } from "../standin/evidence.ts";
import { parseBuild, parseVerdict } from "../standin/parse-verdict.ts";
import type { Frame } from "../standin/lab-standin.ts";
import { graph, event, type Graph, type Event } from "./wire.ts";
import { activeBranch, decodeReminders } from "./reminders.ts";
import { libraryChange, type LibraryChange } from "../standin/library-change.ts";

export type Span = { from: number; through: number };
export type RpcRecord = Frame & { raw: string; agent: string; direction: "send" | "receive"; at: string };
export type HttpRef = { metadata: string };
export type HttpBounds = { kind: "before"; send: number } | { kind: "after"; receive: number } | { kind: "between"; receive: number; send: number } | { kind: "during"; send: number; receive: number };
export type RecordedCampaign = { evidenceDir: string; inputDir: string; a0Verdict: string; build: Build; reproduce: string };
export type NativeTranscript = { session: string; init: { task: string; tools: string[] }; entries: Record<string, unknown>[]; source: Source };
export type RecordedSpec = (context: RecordedContext, scenario: Record<string, unknown>) => Promise<void>;
export type RecordedFlow = "F07" | "F19" | "F22" | "F26" | "F27" | "F28" | "F29" | "F30";

export function span(input: unknown): Span {
	const row = object(input), from = number(row.from), through = number(row.through);
	if (!Number.isSafeInteger(from) || !Number.isSafeInteger(through) || from < 1 || through < from) throw new Error("Invalid inclusive RPC span");
	return { from, through };
}
export function httpRef(input: unknown): HttpRef {
	const row = object(input), metadata = text(row.metadata);
	if (!metadata.endsWith(".json") || row.body !== undefined) throw new Error("HTTP refs name one metadata file; its sibling .body is derived");
	return { metadata };
}

/** Indexes locate owner observations. They never substitute for an HTTP response, RPC frame or native entry. */
export class RecordedContext {
	readonly assertions: Assertion[] = [];
	readonly runs = new Set<string>();
	readonly agents = new Set<string>();
	readonly rpc: RpcRecord[] = [];
	#inputEvidence: string | undefined;
	constructor(readonly config: RecordedCampaign, readonly evidence: Evidence) {}
	async file(path: string): Promise<string> {
		if (isAbsolute(path) || normalize(path) !== path || path === ".." || path.startsWith("../")) throw new Error("Evidence references must stay relative to inputDir");
		const raw = await Bun.file(join(this.config.inputDir, path)).text();
		await Bun.write(join(this.evidence.dir, "inputs", path), raw);
		return raw;
	}
	async json(path: string): Promise<unknown> { return JSON.parse(await this.file(path)); }
	async loadRpc(): Promise<void> {
		const raw = await this.file("rpc.jsonl");
		for (const [index, line] of raw.trimEnd().split("\n").entries()) {
			const row = object(JSON.parse(line)), fields = object(JSON.parse(text(row.raw))), direction = row.direction;
			const evidenceId = text(row.evidenceId);
			if (!evidenceId || (this.#inputEvidence !== undefined && evidenceId !== this.#inputEvidence)) throw new Error("RPC rows do not share one recorded Evidence namespace");
			this.#inputEvidence = evidenceId;
			if (direction !== "send" && direction !== "receive") throw new Error("Unknown RPC evidence direction");
			this.rpc.push({ type: text(fields.type), fields, raw: text(row.raw), line: index + 1, agent: text(row.channel), direction, at: text(row.at) });
		}
		// Source.frame remains the original one-based ledger line, including send and foreign-channel records.
		await Bun.write(join(this.evidence.dir, "rpc.jsonl"), raw);
	}
	frames(agent: string, range: Span): RpcRecord[] {
		if (range.through > this.rpc.length) throw new Error("RPC span exceeds the original ledger");
		this.agents.add(agent);
		return this.rpc.filter(frame => frame.agent === agent && frame.direction === "receive" && frame.line >= range.from && frame.line <= range.through);
	}
	source(frame: { line: number }, agent: string): Source { return { kind: "rpc", agent, frame: String(frame.line) }; }
	check(id: string, claim: string, source: Source, expected: unknown, observed: unknown): void {
		this.assertions.push({ id, claim, source, expected: JSON.stringify(expected) ?? "undefined", observed: JSON.stringify(observed) ?? "undefined", pass: isDeepStrictEqual(expected, observed) });
	}
	async http(ref: HttpRef, path: string, bounds?: HttpBounds, method = "GET", expectedStatus = 200): Promise<string> {
		const metadata = object(await this.json(ref.metadata)), raw = await this.file(`${ref.metadata.slice(0, -5)}.body`);
		if (metadata.method !== method || metadata.path !== path || metadata.status !== expectedStatus) throw new Error(`HTTP observation does not establish ${method} ${path} -> ${expectedStatus}`);
		if (!this.#inputEvidence || metadata.evidenceId !== this.#inputEvidence) throw new Error("HTTP metadata belongs to another recorded Evidence namespace");
		const request = number(metadata.requestRpcLine), response = number(metadata.responseRpcLine);
		if (!Number.isSafeInteger(request) || !Number.isSafeInteger(response) || request < 0 || response < request || response > this.rpc.length) throw new Error("HTTP observation lacks valid same-ledger request/response watermarks");
		if (bounds?.kind === "before" || bounds?.kind === "between") {
			if (this.rpc[bounds.send - 1]?.direction !== "send" || response >= bounds.send) throw new Error("The snapshot was not observed before the causal RPC send");
		}
		if (bounds?.kind === "after" || bounds?.kind === "between") {
			if (this.rpc[bounds.receive - 1]?.direction !== "receive" || request < bounds.receive) throw new Error("The snapshot was not requested after the required RPC result");
		}
		if (bounds?.kind === "during" && (this.rpc[bounds.send - 1]?.direction !== "send" || this.rpc[bounds.receive - 1]?.direction !== "receive" || request >= bounds.send || response < bounds.receive)) throw new Error("The HTTP observation did not enclose the causal RPC action");
		return raw;
	}
	async stream(ref: HttpRef, path: string, bounds: { send: number; receive: number }): Promise<{ raw: string; rpcLine: number }[]> {
		const raw = await this.http(ref, path, { kind: "during", ...bounds }), metadata = object(await this.json(ref.metadata)), capture = object(metadata.capture);
		const headers = list(metadata.headers).map(pair => list(pair));
		if (capture.kind !== "stream" || !headers.some(pair => pair[0] === "content-type" && text(pair[1]).startsWith("text/event-stream"))) throw new Error("Missing an actual SSE observation");
		const ready = number(capture.headersRpcLine), response = number(metadata.responseRpcLine);
		if (!Number.isSafeInteger(ready) || ready < number(metadata.requestRpcLine) || ready >= bounds.send) throw new Error("SSE headers were not observed before the causal prompt");
		const blocks = list(capture.blocks).map(input => { const row = object(input); return { raw: text(row.raw), rpcLine: number(row.rpcLine) }; });
		const parts = raw.split(/\r?\n\r?\n/), tail = parts.pop();
		if (tail?.trim()) throw new Error("SSE body ends inside an incomplete block");
		if (!isDeepStrictEqual(parts, blocks.map(block => block.raw))) throw new Error("SSE arrival observations omit, reorder or replace raw body blocks");
		let previous = ready;
		for (const block of blocks) {
			if (!Number.isSafeInteger(block.rpcLine) || block.rpcLine < previous || block.rpcLine > response) throw new Error("Invalid SSE block arrival watermark");
			previous = block.rpcLine;
		}
		return blocks;
	}
	async readerClose(path: string, channel: string): Promise<{ code: number; rpcLine: number; sendRpcLine: number }> {
		const row = object(await this.json(path)), code = number(row.code), rpcLine = number(row.rpcLine), sendRpcLine = number(row.sendRpcLine);
		if (!this.#inputEvidence || row.evidenceId !== this.#inputEvidence || row.channel !== channel || !Number.isSafeInteger(code) || !Number.isSafeInteger(rpcLine) || !Number.isSafeInteger(sendRpcLine) || sendRpcLine < 1 || rpcLine < sendRpcLine || rpcLine > this.rpc.length || this.rpc[sendRpcLine - 1]?.direction !== "send" || this.rpc[sendRpcLine - 1]?.agent !== channel) throw new Error("Reader close does not belong to this input namespace and actual raw send");
		return { code, rpcLine, sendRpcLine };
	}
	async libraryChange(path: string): Promise<LibraryChange> {
		const change = libraryChange(await this.json(path));
		if (change.evidenceId !== this.#inputEvidence || !Number.isSafeInteger(change.startedRpcLine) || !Number.isSafeInteger(change.finishedRpcLine) || change.startedRpcLine < 0 || change.finishedRpcLine < change.startedRpcLine || change.finishedRpcLine > this.rpc.length) throw new Error("Library change does not belong to this recording's observation boundaries");
		return change;
	}
	async graph(ref: HttpRef, run: string, bounds?: HttpBounds): Promise<Graph> {
		const result = graph(JSON.parse(await this.http(ref, `/runs/${run}/graph`, bounds)));
		if (result.run !== run) throw new Error("Graph identity differs from the indexed run");
		this.runs.add(run); return result;
	}
	async events(ref: HttpRef, run: string, through: number, bounds?: HttpBounds): Promise<Event[]> {
		const raw = await this.http(ref, `/runs/${run}/stream?after=0`, bounds), events: Event[] = [];
		for (const block of raw.split(/\r?\n\r?\n/)) {
			const data = block.split(/\r?\n/).filter(line => line.startsWith("data:")).map(line => line.slice(5).replace(/^ /, "")).join("\n");
			if (!data) continue;
			const item = event(JSON.parse(data));
			if (!Number.isSafeInteger(item.seq) || item.seq <= (events.at(-1)?.seq ?? 0) || item.seq > through) throw new Error("Recorded SSE is outside its monotonic snapshot prefix");
			events.push(item);
		}
		if (events.at(-1)?.seq !== through) throw new Error("Recorded SSE does not reach the owning graph snapshot");
		return events;
	}
	async transcript(path: string): Promise<NativeTranscript> {
		const raw = await this.file(path), rows = raw.trimEnd().split("\n").map(line => object(JSON.parse(line)));
		const header = rows[0];
		if (!header || header.type !== "session") throw new Error("Missing native session header");
		const inits = rows.filter(row => row.type === "session_init");
		if (inits.length !== 1) throw new Error("The fresh child transcript needs exactly one native session_init");
		const init = inits[0]!;
		return { session: text(header.id), init: { task: text(init.task), tools: list(init.tools).map(text) }, entries: rows.slice(1), source: { kind: "transcript", file: `inputs/${path}`, lines: [1, rows.length] } };
	}
	reminders(root: string, range: Span, customType: string) {
		const frames = this.frames(root, range), snapshot = frames.findLast(frame => frame.type === "response" && frame.fields.command === "get_entries" && frame.fields.success === true);
		if (!snapshot) throw new Error("No owner get_entries snapshot in the requested phase");
		const data = object(snapshot.fields.data);
		return decodeReminders(data.entries, data.leafId, customType, snapshot.line);
	}
	state(agent: string, range: Span): { session: string; frame: RpcRecord } {
		const result = this.frames(agent, range).findLast(frame => frame.type === "response" && frame.fields.command === "get_state" && frame.fields.success === true);
		if (!result) throw new Error("No native get_state response for the indexed child");
		return { session: text(object(result.fields.data).sessionId), frame: result };
	}
	prompt(root: string, range: Span, expectedMessage?: string) {
		const frames = this.frames(root, range), sends = this.rpc.filter(frame => frame.agent === root && frame.direction === "send" && frame.type === "prompt" && frame.line >= range.from && frame.line <= range.through && (expectedMessage === undefined || frame.fields.message === expectedMessage));
		if (sends.length !== 1) throw new Error("The phase needs one uniquely indexed actual prompt send");
		const sent = sends[0]!, id = text(sent.fields.id), expected = text(sent.fields.message);
		const acknowledged = frames.find(frame => frame.type === "response" && frame.fields.command === "prompt" && frame.fields.id === id && frame.fields.success === true);
		const completed = frames.find(frame => frame.type === "prompt_result" && frame.fields.id === id && frame.fields.status === "completed");
		const users = frames.filter(frame => {
			if (frame.type !== "message_end" || frame.line <= sent.line || object(frame.fields.message).role !== "user") return false;
			const content = object(frame.fields.message).content;
			const body = typeof content === "string" ? content : list(content).map(block => { const row = object(block); return row.type === "text" ? text(row.text) : ""; }).join("");
			return body === expected && completed !== undefined && frame.line < completed.line;
		});
		if (!acknowledged || !completed || users.length !== 1) throw new Error("The exact prompt did not produce one actual native user input and completed turn");
		const snapshot = frames.findLast(frame => frame.type === "response" && frame.fields.command === "get_entries" && frame.fields.success === true && frame.line > completed.line);
		if (!snapshot) throw new Error("The prompt needs a later authoritative active-branch get_entries snapshot");
		const data = object(snapshot.fields.data), branch = activeBranch(data.entries, data.leafId);
		const matching = branch.filter(entry => entry.body.kind === "message" && isDeepStrictEqual(entry.body.message, users[0]!.fields.message));
		if (matching.length !== 1) throw new Error("The actual prompt user message is not uniquely persisted on the active branch");
		const userEntry = matching[0]!.id, calls = new Map<string, string>();
		let currentUser: string | null = null;
		for (const entry of branch) {
			if (entry.body.kind !== "message") continue;
			const message = object(entry.body.message);
			if (message.role === "user") currentUser = entry.id;
			if (message.role === "assistant" && currentUser === userEntry) for (const block of list(message.content).map(object)) if (block.type === "toolCall") calls.set(text(block.id), entry.id);
		}
		return { sent, user: users[0]!, completed, snapshot, branch, userEntry, calls };
	}
}

export async function runRecorded(flow: RecordedFlow, config: RecordedCampaign, spec: RecordedSpec): Promise<Verdict> {
	const startedAt = new Date().toISOString(), evidence = await Evidence.create(config.evidenceDir), context = new RecordedContext(config, evidence);
	try {
		const a0 = parseVerdict(await Bun.file(config.a0Verdict).json());
		if (a0.segment !== "A0" || a0.result.kind !== "pass" || a0.build.release !== config.build.release) throw new Error("Same-release full A0 has not passed");
		if (!/^[a-f0-9]{64}$/.test(config.build.release) || !Object.keys(config.build.commits).length || Object.values(config.build.commits).some(commit => !/^[a-f0-9]{40}$/.test(commit)) || !Object.keys(config.build.images).length || Object.values(config.build.images).some(image => !/sha256:[a-f0-9]{64}$/.test(image)) || config.build.omp === "fixture" || config.build.model === "fixture") throw new Error("Recorded live acceptance needs real build identities");
		await Bun.write(join(evidence.dir, "a0-verdict.json"), JSON.stringify(a0, null, 2));
		await context.loadRpc();
		const scenario = object(await context.json("scenario.json"));
		if (scenario.flow !== flow) throw new Error("Scenario index belongs to another flow");
		await spec(context, scenario);
		if (!context.assertions.length) throw new Error("No behavior assertions were evaluated");
	} catch (error) {
		const observed = error instanceof Error ? error.stack ?? error.message : String(error);
		await Bun.write(join(evidence.dir, "execution-error.txt"), observed);
		context.check("execution", "All required owner observations and phases are available", { kind: "transcript", file: "execution-error.txt", lines: [1, observed.split("\n").length] }, "complete native/RPC/store evidence", observed);
	}
	const failed = context.assertions.filter(assertion => !assertion.pass).map(assertion => assertion.id);
	const verdict: Verdict = { flow, segment: "S1", env: "L", startedAt, endedAt: new Date().toISOString(), build: config.build, runs: [...context.runs], agents: [...context.agents], remoteRuns: [], assertions: context.assertions, deviations: [], result: failed.length ? { kind: "fail", failed } : { kind: "pass" } };
	await evidence.verdict(verdict, config.reproduce); return verdict;
}
export async function recordedMain(flow: RecordedFlow, spec: RecordedSpec): Promise<void> {
	const index = process.argv.indexOf("--config"), path = process.argv[index + 1];
	if (index < 0 || !path) throw new Error("Provide --config /absolute/path/to/recorded-campaign.json");
	const row = object(await Bun.file(path).json());
	const verdict = await runRecorded(flow, { evidenceDir: text(row.evidenceDir), inputDir: text(row.inputDir), a0Verdict: text(row.a0Verdict), reproduce: text(row.reproduce), build: parseBuild(row.build) }, spec);
	console.log(JSON.stringify({ flow, result: verdict.result, evidence: row.evidenceDir })); process.exitCode = verdict.result.kind === "pass" ? 0 : 1;
}
