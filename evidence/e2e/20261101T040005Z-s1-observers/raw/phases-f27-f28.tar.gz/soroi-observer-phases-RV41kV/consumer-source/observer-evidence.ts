import { list, number, object, text, type Source } from "../standin/evidence.ts";
import { evalRecords } from "./agent-evidence.ts";
import { httpRef, span, type RecordedContext } from "./recorded.ts";
import type { Graph, Node } from "./wire.ts";
import { callArguments } from "./predicates.ts";

export const CALC_CODE = "const calc_input = 21\nconst calc_output = calc(calc_input)";
export const storeSource = (path: string, method = "GET"): Source => ({ kind: "store", method, path });

/** A scenario locates a turn; the native active branch and tool result establish what actually ran. */
export function evaluation(context: RecordedContext, input: unknown, mode: "formal" | "dry_run", code: string) {
	const phase = object(input), root = text(phase.root), range = span(phase.span), frames = context.frames(root, range);
	const request = context.prompt(root, range), records = evalRecords(frames);
	if (records.length !== 1) throw new Error("An observation phase needs exactly one actual eval");
	const record = records[0]!, state = context.state(root, range);
	const originalEntry = request.branch.find(entry => entry.id === request.calls.get(record.id));
	if (!originalEntry || originalEntry.body.kind !== "message") throw new Error("Eval has no original native assistant entry on this request's branch");
	const original = list(object(originalEntry.body.message).content).map(object).filter(block => block.type === "toolCall" && block.id === record.id);
	if (original.length !== 1) throw new Error("Expected one uniquely identified original native eval tool call");
	const arguments_ = object(original[0]!.arguments);
	context.check(`${root}-${record.id}-request`, "The completed eval and original native assistant arguments both belong to this exact scripted prompt", context.source(record.result, root), [1, "soroi_eval", mode, code, mode, code, false, true], [request.calls.size, original[0]!.name, arguments_.mode, arguments_.code, record.mode, record.code, record.isError, record.result.line < request.completed.line]);
	if (record.report.kind !== mode) throw new Error("The eval did not return the required structured report");
	return { phase, root, range, frames, request, record, state };
}

export async function committed(context: RecordedContext, input: unknown, code: string) {
	const result = evaluation(context, input, "formal", code);
	if (result.record.report.kind !== "formal") throw new Error("Expected formal eval");
	const run = result.record.report.runId;
	const graph = await context.graph(httpRef(result.phase.graph), run, { kind: "after", receive: result.record.result.line });
	context.check(`${result.root}-${result.record.id}-holder`, "The committed run belongs to the actual native root session", storeSource(`/runs/${run}/graph`), result.state.session, graph.holder);
	const events = await context.events(httpRef(result.phase.events), run, graph.at, { kind: "after", receive: result.record.result.line });
	const steps = events.filter(event => event.kind === "step_committed" && event.step.code === code && event.step.session === result.state.session);
	if (steps.length !== 1) throw new Error("The actual scripted step is not uniquely committed by its native session");
	const commit = object(result.phase.commit), ref = httpRef(commit);
	const response = object(JSON.parse(await context.http(ref, "/runs/steps", undefined, "POST", 201)));
	const request = object(await context.json(text(commit.request))), requestedRun = object(request.run), metadata = object(await context.json(ref.metadata));
	const cursor = number(response.seq), step = steps[0]!.seq;
	if (!Number.isSafeInteger(cursor) || cursor < step || cursor > graph.at) throw new Error("Commit response cursor does not contain the selected current step");
	context.check(`${result.root}-${result.record.id}-commit`, "A real owning POST during this eval commits its exact code, session and run; historical steps cannot substitute", storeSource("/runs/steps", "POST"), [result.state.session, code, run, true, true, result.record.report.runStarted], [request.session, request.code, response.run, requestedRun.kind === "open" ? requestedRun.session === result.state.session : requestedRun.kind === "existing" && requestedRun.run === run, number(metadata.requestRpcLine) >= result.request.sent.line && number(metadata.responseRpcLine) < result.record.result.line, requestedRun.kind === "open"]);
	return { ...result, run, graph, events, step, cursor };
}

export function calcNode(graph: Graph, step: number): Extract<Node, { kind: "Call" }> {
	const matches = graph.nodes.filter(node => node.kind === "Call" && node.step === step && node.fn === "calc");
	if (matches.length !== 1 || matches[0]!.kind !== "Call") throw new Error("Expected one committed calc in this step");
	return matches[0]!;
}
export function checkCalc(context: RecordedContext, graph: Graph, step: number, inputName: string, outputName: string, expected: number): void {
	const call = calcNode(graph, step), root = graph.nodes.find(node => node.kind === "Root" && node.name === inputName);
	context.check(`${graph.run}-${step}-calc`, "The named calc consumes the scripted input by position and commits its observed numeric result", storeSource(`/runs/${graph.run}/graph`), ["Program", { kind: "scalar", scalar: { kind: "number", v: 21 } }, [{ from: inputName, to: { step, position: call.position, input: 0 } }], [{ field: "", name: outputName, value: { kind: "scalar", scalar: { kind: "number", v: expected } } }]], [call.body, root?.kind === "Root" ? root.value : null, graph.edges.filter(edge => edge.to.step === step && edge.to.position === call.position), call.outputs]);
}
export function ensureSuccessfulCalc(input: ReturnType<typeof evaluation>): void {
	const report = input.record.report;
	if (report.kind !== "formal" && report.kind !== "dry_run") throw new Error("Expected eval CallReport");
	if (report.calls.length !== 1 || callArguments(report.calls[0]!.call, "calc").length !== 1 || !["ran", "reused"].includes(report.calls[0]!.outcome)) throw new Error("The actual calc did not complete successfully");
}

export function sse(raw: string): Record<string, unknown>[] {
	return raw.split(/\r?\n\r?\n/).flatMap(block => {
		const lines = block.split(/\r?\n/), data = lines.filter(line => line.startsWith("data:")).map(line => line.slice(5).replace(/^ /, "")).join("\n");
		if (!data) return [];
		return [object(JSON.parse(data))];
	});
}
export function versionRecord(input: unknown) {
	const row = object(input);
	return { version: text(row.version), bundle: text(row.bundle), entry: text(row.entry), sources: text(row.sources), commit: text(row.commit), buildManifest: text(row.buildManifest), lockfile: text(row.lockfile) };
}
