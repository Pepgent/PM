import { list, number, object, text } from "../standin/evidence.ts";

export type Value =
	| { kind: "scalar"; scalar: { kind: "number"; v: number } | { kind: "string"; v: string } | { kind: "boolean"; v: boolean } | { kind: "null" } }
	| { kind: "file"; content: string; media: string; name: string };
export type Environment = { kind: "central" } | { kind: "remote"; template: string; remoteRun: string };
export type CallStatus = { kind: "Ended" } | { kind: "Adopted" } | { kind: "Human" } | { kind: "Inherited"; sourceRun: string; sourceStep: number; sourcePosition: number };
export type Node =
	| { kind: "Root"; name: string; value: Value }
	| { kind: "Call"; step: number; position: number; fn: string; version: string; body: "Program" | "Agent" | "Human"; env: Environment; status: CallStatus; startedAt: string; endedAt: string; transcript: string | null; outputs: { field: string; name: string; value: Value }[] }
	| { kind: "AbortedCall"; step: number; position: number; fn: string; startedAt: string; endedAt: string; transcript: string | null; outputs: [] };
export type Graph = { run: string; holder: string; derivedFrom: null; state: "Open" | "Ended" | "Aborted"; at: number; nodes: Node[]; edges: { from: string; to: { step: number; position: number; input: number } }[]; unconsumed: string[] };
export type Atom = { name: string; value: Value; origin: string };
export type Event =
	| { kind: "run_started" | "run_ended" | "run_aborted"; seq: number; at: string }
	| { kind: "step_committed"; seq: number; at: string; step: { session: string; code: string } }
	| { kind: "atom_stopped"; seq: number; at: string; name: string }
	| { kind: "call_started" | "call_ended" | "call_adopted" | "call_inherited" | "call_aborted" | "human_handback"; seq: number; at: string; call: Node };
export type CheckError =
	| { kind: "statement_form"; at: number }
	| { kind: "unknown_atom" | "duplicate_name"; name: string }
	| { kind: "unknown_node" | "output_not_flat" | "unpinned_human_in_dry_run"; fn: string }
	| { kind: "type_error"; message: string }
	| { kind: "destructure_mismatch"; fn: string; missing: string[]; extra: string[] }
	| { kind: "partial_pin"; fn: string; unpinned: string[] }
	| { kind: "pin_kind"; name: string; expected: "number" | "string" | "boolean" | "file" }
	| { kind: "env_key"; name: string }
	| { kind: "env_conflict"; fn: string; templates: string[] }
	| { kind: "unknown_template"; template: string };
export type CallReport = { call: string; outcome: "ran" | "reused" | "pinned" | "human" | "failed"; env: string; outputs: Record<string, string>; agentId?: string };
export type EvalOutcome =
	| { kind: "formal"; runId: string; runStarted: boolean; runEnded: boolean; calls: CallReport[] }
	| { kind: "dry_run"; calls: CallReport[] }
	| { kind: "check_error"; errors: CheckError[] }
	| { kind: "schema_error"; message: string }
	| { kind: "tool_error"; message: string };
export type Pin = number | string | boolean | { file: string };
export type EvalInput = { mode: "formal"; code: string } | { mode: "dry_run"; code: string; pins?: Record<string, Pin> };
/** Intentionally invalid request, used only to observe rejection at the real host schema boundary. */
export type FormalPinsProbe = { mode: "formal"; code: string; pins: Record<string, Pin> };
export type Presence = { agentId: string; generation: { id: string; where: { kind: "local"; host: string } | { kind: "remote"; runId: string } } | null };
export type Activity = { run: string; intervals: { step: number; position: number; fn: string; startedAt: string; endedAt: string | null }[] };
export type Reminder = { entryId: string; at: string; line: number; phase: "before_provider_request"; requestOrdinal: number; text: string; assistantEntry: string; toolCalls: string[] };

export function flag(input: unknown): boolean {
	if (typeof input !== "boolean") throw new Error("Expected boolean");
	return input;
}
export function value(input: unknown): Value {
	const row = object(input);
	if (row.kind === "file") return { kind: "file", content: text(row.content), media: text(row.media), name: text(row.name) };
	if (row.kind !== "scalar") throw new Error("Unknown value kind");
	const scalar = object(row.scalar);
	switch (scalar.kind) {
		case "number": return { kind: "scalar", scalar: { kind: "number", v: number(scalar.v) } };
		case "string": return { kind: "scalar", scalar: { kind: "string", v: text(scalar.v) } };
		case "boolean": return { kind: "scalar", scalar: { kind: "boolean", v: flag(scalar.v) } };
		case "null": return { kind: "scalar", scalar: { kind: "null" } };
		default: throw new Error("Unknown scalar kind");
	}
}
function environment(input: unknown): Environment {
	const row = object(input);
	switch (row.kind) { case "central": return { kind: row.kind }; case "remote": return { kind: row.kind, template: text(row.template), remoteRun: text(row.remoteRun) }; default: throw new Error("Unknown environment"); }
}
function status(input: unknown): CallStatus {
	const row = object(input);
	switch (row.kind) {
		case "Ended": case "Adopted": case "Human": return { kind: row.kind };
		case "Inherited": return { kind: row.kind, sourceRun: text(row.sourceRun), sourceStep: number(row.sourceStep), sourcePosition: number(row.sourcePosition) };
		default: throw new Error("Unknown call status");
	}
}
export function node(input: unknown): Node {
	const row = object(input);
	switch (row.kind) {
		case "Root": return { kind: "Root", name: text(row.name), value: value(row.value) };
		case "Call": {
			const body = row.body;
			if (body !== "Program" && body !== "Agent" && body !== "Human") throw new Error("Unknown node body");
			return { kind: "Call", step: number(row.step), position: number(row.position), fn: text(row.fn), version: text(row.version), body, env: environment(row.env), status: status(row.status), startedAt: text(row.startedAt), endedAt: text(row.endedAt), transcript: row.transcript === null ? null : text(row.transcript),
				outputs: list(row.outputs).map(input => { const output = object(input); return { field: text(output.field), name: text(output.name), value: value(output.value) }; }) };
		}
		case "AbortedCall":
			if (list(row.outputs).length) throw new Error("Aborted calls cannot have outputs");
			return { kind: "AbortedCall", step: number(row.step), position: number(row.position), fn: text(row.fn), startedAt: text(row.startedAt), endedAt: text(row.endedAt), transcript: row.transcript === null ? null : text(row.transcript), outputs: [] };
		default: throw new Error(`Unknown graph node ${String(row.kind)}`);
	}
}
export function graph(input: unknown): Graph {
	const row = object(input), state = row.state;
	if (state !== "Open" && state !== "Ended" && state !== "Aborted") throw new Error("Unknown graph state");
	if (row.derivedFrom !== null) throw new Error("These S1 scenarios require a root run");
	return { run: text(row.run), holder: text(row.holder), derivedFrom: null, state, at: number(row.at), nodes: list(row.nodes).map(node), unconsumed: list(row.unconsumed).map(text),
		edges: list(row.edges).map(input => { const edge = object(input), to = object(edge.to); return { from: text(edge.from), to: { step: number(to.step), position: number(to.position), input: number(to.input) } }; }) };
}
export function event(input: unknown): Event {
	const row = object(input), base = { seq: number(row.seq), at: text(row.at) };
	switch (row.kind) {
		case "run_started": case "run_ended": case "run_aborted": return { ...base, kind: row.kind };
		case "atom_stopped": return { ...base, kind: row.kind, name: text(row.name) };
		case "step_committed": { const step = object(row.step); return { ...base, kind: row.kind, step: { session: text(step.session), code: text(step.code) } }; }
		case "call_started": case "call_ended": case "call_adopted": case "call_inherited": case "call_aborted": case "human_handback": return { ...base, kind: row.kind, call: node(row.call) };
		default: throw new Error(`Unknown store event ${String(row.kind)}`);
	}
}
function checkError(input: unknown): CheckError {
	const row = object(input);
	switch (row.kind) {
		case "statement_form": return { kind: row.kind, at: number(row.at) };
		case "unknown_atom": case "duplicate_name": return { kind: row.kind, name: text(row.name) };
		case "unknown_node": case "output_not_flat": case "unpinned_human_in_dry_run": return { kind: row.kind, fn: text(row.fn) };
		case "type_error": return { kind: row.kind, message: text(row.message) };
		case "destructure_mismatch": return { kind: row.kind, fn: text(row.fn), missing: list(row.missing).map(text), extra: list(row.extra).map(text) };
		case "partial_pin": return { kind: row.kind, fn: text(row.fn), unpinned: list(row.unpinned).map(text) };
		case "pin_kind": {
			const expected = row.expected;
			if (expected !== "number" && expected !== "string" && expected !== "boolean" && expected !== "file") throw new Error("Unknown pin field kind");
			return { kind: row.kind, name: text(row.name), expected };
		}
		case "env_key": return { kind: row.kind, name: text(row.name) };
		case "env_conflict": return { kind: row.kind, fn: text(row.fn), templates: list(row.templates).map(text) };
		case "unknown_template": return { kind: row.kind, template: text(row.template) };
		default: throw new Error(`Unknown CheckError ${String(row.kind)}`);
	}
}
export function evalOutcome(details: unknown, isError: boolean, message: string): EvalOutcome {
	if (details === undefined || details === null) {
		if (isError) return { kind: "tool_error", message };
		throw new Error("Successful eval is missing structured details");
	}
	const row = object(details);
	if (isError && row.isError === true && typeof row.error === "string") return { kind: "schema_error", message: row.error };
	if (row.ok === false) return { kind: "check_error", errors: list(row.errors).map(checkError) };
	if (isError) return { kind: "tool_error", message };
	const calls: CallReport[] = list(row.calls).map(input => {
		const call = object(input), outcome = call.outcome;
		if (outcome !== "ran" && outcome !== "reused" && outcome !== "pinned" && outcome !== "human" && outcome !== "failed") throw new Error("Unknown call outcome");
		return { call: text(call.call), outcome, env: text(call.env), outputs: Object.fromEntries(Object.entries(object(call.outputs)).map(([key, value]) => [key, text(value)])), ...(call.agentId === undefined ? {} : { agentId: text(call.agentId) }) };
	});
	switch (row.mode) {
		case "dry_run": return { kind: row.mode, calls };
		case "formal": return { kind: row.mode, runId: text(row.runId), runStarted: flag(row.runStarted), runEnded: flag(row.runEnded), calls };
		default: throw new Error("Unknown eval result mode");
	}
}
